# subly-wban

Simulation code, raw results, and manuscript source for SUBLY: submodular
cluster-head selection with Lyapunov-optimised forwarding for IoT-enabled
wireless body area networks (WBANs).

Version 1.0.0.

## What this repository contains

A slotted discrete-event simulator for a multi-patient WBAN ward, seven routing
protocols implemented against a common interface, the raw per-trial output of
six experiments, and the scripts that turn that output into the tables and
figures used in the manuscript.

**Simulator** (`src/subly/`)

| Module | Contents |
| --- | --- |
| `config.py` | Every tunable parameter, as a frozen dataclass (`Config`, `DEFAULT`) |
| `network.py` | Node placement, reference-point group mobility, log-distance channel with log-normal shadowing, power-controlled energy model, hub-potential field |
| `simulator.py` | Slotted engine; one `run()` call is one (protocol, seed) pair |
| `stats.py` | Paired *t*-test, Wilcoxon signed-rank, Cohen's *d_z*, Holm–Bonferroni correction |
| `registry.py` | Name → protocol factory mapping, including the ablation variants |

**Protocols** (`src/subly/protocols/`)

`base.py` defines the interface (`round_start`, `select_next_hops`,
`on_result`) and the shared link estimator. `baselines.py` contains DTx, LEACH,
SIMPLE, M-ATTEMPT, EHCRP and QQAR, described in that file's docstring as
re-implementations of the published decision rules rather than of the original
authors' code. `subly.py` contains SUBLY and its two ablation switches
(`use_submodular`, `use_lyapunov`), which together give the four variants
`SUBLY`, `SUBLY-noSub`, `SUBLY-noLyap`, `SUBLY-neither`.

All protocols receive the same `Config` and the same seed, so node placement,
mobility, shadowing, traffic and initial energy are identical across protocols
within a trial.

## Directory structure

```
.
├── README.md
├── AUTHOR_ACTIONS.md      # open items requiring the author's judgment
├── .gitignore
├── pyproject.toml
├── requirements.txt
├── src/subly/             # simulator package
│   └── protocols/         # routing protocols
├── tests/                 # invariant tests
├── scripts/               # experiment driver, table and figure generators
├── results/raw/           # raw per-trial CSV output (committed)
├── tables/                # generated LaTeX tables (committed)
├── figures/               # generated PDF figures (committed)
└── paper/                 # manuscript source (main.tex, fig_*.tex)
```

`tables/` and `figures/` are generated from `results/raw/` by the scripts below
and are committed so the manuscript builds without rerunning the experiments.

## Requirements

Python >= 3.10, with `numpy>=1.24`, `scipy>=1.10`, `matplotlib>=3.7`
(`pytest>=7.0` for the tests). Verified on Python 3.12.3 with numpy 2.4.4 and
scipy 1.17.1.

## Installation

```bash
pip install .
```

or, for development:

```bash
pip install -e ".[dev]"
```

The package installs as `subly` from `src/`.

## Running the tests

```bash
pytest
```

`pyproject.toml` sets `pythonpath = ["src"]` and `testpaths = ["tests"]`, so
`pytest` works from the repository root without installing the package.

The suite checks that the cluster-head utility is monotone and submodular, that
lazy greedy returns the same set as plain greedy, that every admissible hop
strictly increases the hub potential, that the potential is bounded in (0, 1],
that packets and energy are conserved, that all protocols see an identical
network for a given seed, that `V` moves energy and delay in opposite
directions, and that every ablation variant runs.

## Reproducing the experiments

```bash
python scripts/run_experiments.py all
```

Writes one CSV per experiment to `results/raw/`. Individual experiments and
options:

```bash
python scripts/run_experiments.py main scalability   # subset
python scripts/run_experiments.py --seeds 5 main     # fewer seeds
python scripts/run_experiments.py --tag _check main  # write main_check.csv
python scripts/run_experiments.py --protocols DTx,SUBLY main
```

Use `--tag` to compare a fresh run against the committed CSVs without
overwriting them; `results/raw/*_verify.csv` and `*_repro.csv` are gitignored.

| Experiment | Configuration | Seeds | Output |
| --- | --- | --- | --- |
| `main` | N = 64, E0 = 0.50 J, 1600 slots | 30 | `main.csv` |
| `lifetime` | N = 64, E0 = 0.12 J, 2400 slots | 20 | `lifetime.csv` |
| `scalability` | N = 16, 32, 64, 96, 128; 1000 slots | 8 | `scalability.csv` |
| `mobility` | v_max = 0.0–2.4 m/s; 1200 slots | 8 | `mobility.csv` |
| `vsweep` | V = 0.25–32, SUBLY only; 1200 slots | 10 | `vsweep.csv` |
| `ablation` | four SUBLY variants; 1600 slots | 10 | `ablation.csv` |

Measured wall-clock time for a full `all` run on one core of the machine used
for the last verification: main 177 s, lifetime and mobility 189 s,
scalability 175 s, vsweep 132 s, ablation 79 s.

## Regenerating tables and figures

```bash
python scripts/make_tables.py     # results/raw/*.csv -> tables/*.tex
python scripts/make_figures.py    # results/raw/*.csv -> figures/*.pdf
```

`make_tables.py` also prints a summary and writes `tables/key_numbers.txt`.
Both scripts read only `results/raw/`, so they can be rerun without rerunning
the simulations. `make_figures.py` suppresses the PDF `/CreationDate` metadata,
so regenerating the figures from unchanged data produces byte-identical files
and no spurious diff.

## Building the manuscript

```bash
cd paper
pdflatex main.tex && pdflatex main.tex && pdflatex main.tex
```

`main.tex` reads figures from `../figures/` and tables from `../tables/`.
Three passes are needed for cross-references to settle. The bibliography is a
`thebibliography` environment inside `main.tex`; no BibTeX run is required.

## License

MIT, as declared in `pyproject.toml`. The full text is in `LICENSE`.

The copyright line in `LICENSE` reads `<COPYRIGHT HOLDER>` and must be replaced
with the actual holder before publication; the manuscript is anonymised, so the
name could not be filled in automatically.

## Status

Reproducible and complete. One methodological limitation is disclosed rather
than repaired: the SUBLY parameters were fixed on seeds {1, 2, 3}, which overlap
the evaluation range 0-29, and the repository contains no tuning script. See
`AUTHOR_ACTIONS.md`.
