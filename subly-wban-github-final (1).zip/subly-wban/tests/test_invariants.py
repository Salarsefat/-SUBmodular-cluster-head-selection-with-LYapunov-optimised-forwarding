"""
Invariant tests for the claims the paper depends on.

Run with:  PYTHONPATH=src python -m pytest tests -q
       or:  PYTHONPATH=src python tests/test_invariants.py
"""
from __future__ import annotations

import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__))), "src"))

from subly import Config, Network, run                      # noqa: E402
from subly.protocols.base import HUB                        # noqa: E402
from subly.protocols.subly import SUBLY                     # noqa: E402
from subly.registry import PROTOCOLS, make                  # noqa: E402

SHORT = dict(n_slots=300, warmup_slots=40, drain_slots=60, balance_slot=150,
             n_patients=4, target_lifetime_slots=300)


def _subly(seed=0, **kw):
    cfg = Config(**dict(SHORT, **kw))
    net = Network(cfg, seed)
    p = SUBLY(cfg, net, np.random.default_rng(seed))
    p.round_start(0, np.zeros(net.N))
    return cfg, net, p


# ======================================================================
# Step 3: the utility must actually be monotone and submodular, or the
# (1 - 1/e) guarantee quoted in the paper does not hold.
# ======================================================================
def test_utility_is_monotone_and_submodular():
    cfg, net, p = _subly()
    phi, phi_hub, psi = p._phi()
    lam = cfg.lam_modular
    alive = net.alive

    def f(S):
        cover = phi_hub.copy()
        for j in S:
            cover = np.maximum(cover, phi[:, j])
        return float(cover[alive].sum() + lam * sum(psi[j] for j in S))

    rng = np.random.default_rng(7)
    cand = np.flatnonzero(alive)
    base = f([])
    for _ in range(200):
        k = int(rng.integers(0, 6))
        A = list(rng.choice(cand, k, replace=False))
        extra = int(rng.integers(1, 4))
        B = A + [x for x in rng.choice(cand, extra, replace=False) if x not in A]
        j = int(rng.choice([c for c in cand if c not in B] or [cand[0]]))
        # monotonicity: A subset of B  =>  f(A) <= f(B)
        assert f(A) <= f(B) + 1e-9, "utility is not monotone"
        # submodularity: diminishing returns on the larger set
        gain_A = f(A + [j]) - f(A)
        gain_B = f(B + [j]) - f(B)
        assert gain_B <= gain_A + 1e-9, "utility is not submodular"
        assert f(A) >= base - 1e-9
    print("ok  utility monotone + submodular over 200 random set pairs")


def test_lazy_greedy_matches_plain_greedy():
    """Lazy evaluation must return the *same* set, not merely a similar one."""
    cfg, net, p = _subly(seed=3)
    phi, phi_hub, psi = p._phi()
    K = 5
    lazy = list(p._lazy_greedy(phi, phi_hub, psi, K))

    lam = cfg.lam_modular
    alive = net.alive
    cover = phi_hub.copy()
    elig = list(np.flatnonzero(alive & (p.trust >= cfg.trust_floor)))
    plain = []
    for _ in range(min(K, len(elig))):
        best, bj = -np.inf, None
        for j in elig:
            if j in plain:
                continue
            g = float(np.maximum(phi[:, j] - cover, 0.0)[alive].sum()
                      + lam * psi[j])
            if g > best:
                best, bj = g, j
        if bj is None or (best <= 0 and plain):
            break
        plain.append(bj)
        cover = np.maximum(cover, phi[:, bj])
    assert lazy == plain, f"lazy {lazy} != greedy {plain}"
    print(f"ok  lazy greedy == plain greedy, |S| = {len(lazy)}")


# ======================================================================
# Step 6: every admissible hop must strictly increase the potential, or
# the loop-freedom claim is false.
# ======================================================================
def test_admissible_hops_strictly_increase_potential():
    for seed in range(4):
        cfg, net, p = _subly(seed=seed)
        checked = 0
        for i in range(net.N):
            if not net.alive[i]:
                continue
            for j in p.cand[i]:
                if j == HUB:
                    continue
                assert p.pi[j] > p.pi[i], (
                    f"hop {i}->{j} does not increase potential "
                    f"({p.pi[i]:.4f} -> {p.pi[j]:.4f})")
                checked += 1
        assert checked > 0, "no admissible node-to-node hops to check"
    print("ok  all admissible hops strictly increase the potential (loop-free)")


def test_potential_is_bounded():
    cfg, net, p = _subly()
    assert np.all(p.pi > 0.0) and np.all(p.pi <= 1.0 + 1e-12)
    print("ok  potential field bounded in (0, 1]")


# ======================================================================
# Simulator invariants
# ======================================================================
def test_packet_conservation_and_energy_bounds():
    for name in PROTOCOLS:
        cfg = Config(**SHORT)
        r = run(cfg, make(name), seed=1)
        assert r.generated > 0, f"{name}: no traffic generated"
        assert r.delivered <= r.generated, f"{name}: delivered > generated"
        assert -1e-9 <= r.pdr <= 100.0 + 1e-9, f"{name}: PDR out of range"
        assert abs(r.pdr + r.plr - 100.0) < 1e-6, f"{name}: PDR + PLR != 100"
        budget = cfg.e0_j * cfg.n_nodes
        assert 0.0 <= r.energy_total_j <= budget + 1e-9, \
            f"{name}: energy {r.energy_total_j} outside [0, {budget}]"
        assert 0.0 <= r.residual_mean_j <= cfg.e0_j + 1e-9
        assert 0.0 <= r.overhead_pct <= 100.0
        assert 0.0 < r.jain_energy <= 1.0 + 1e-9
        print(f"ok  {name:10s} PDR={r.pdr:6.2f}  E={r.energy_total_j:6.3f} J")


def test_identical_network_across_protocols():
    """The fair-comparison guarantee: same seed => byte-identical network."""
    cfg = Config(**SHORT)
    a, b = Network(cfg, 42), Network(cfg, 42)
    assert np.array_equal(a.pos, b.pos)
    assert np.array_equal(a.energy, b.energy)
    assert np.array_equal(a.critical, b.critical)
    assert np.allclose(a.prr, b.prr)
    c = Network(cfg, 43)
    assert not np.allclose(a.pos, c.pos), "different seeds gave same placement"
    print("ok  network is seed-reproducible and seed-sensitive")


def test_V_controls_the_energy_delay_tradeoff():
    """The direction of the O(1/V)/O(V) trade-off must be observable."""
    lo = [run(Config(**dict(SHORT, V=0.25)), make("SUBLY"), s) for s in (0, 1, 2)]
    hi = [run(Config(**dict(SHORT, V=16.0)), make("SUBLY"), s) for s in (0, 1, 2)]
    d_lo = np.mean([r.delay_mean_s for r in lo])
    d_hi = np.mean([r.delay_mean_s for r in hi])
    e_lo = np.mean([r.energy_per_pkt_mj for r in lo])
    e_hi = np.mean([r.energy_per_pkt_mj for r in hi])
    assert d_hi > d_lo, f"delay did not grow with V ({d_lo:.2f} -> {d_hi:.2f})"
    assert e_hi < e_lo, f"energy did not fall with V ({e_lo:.3f} -> {e_hi:.3f})"
    print(f"ok  V: delay {d_lo:.2f}->{d_hi:.2f} s, "
          f"energy {e_lo*1e3:.0f}->{e_hi*1e3:.0f} uJ/pkt")


def test_ablation_variants_run():
    for name in ("SUBLY-noSub", "SUBLY-noLyap", "SUBLY-neither"):
        r = run(Config(**SHORT), make(name), seed=0)
        assert r.generated > 0 and 0 <= r.pdr <= 100
        print(f"ok  {name:15s} PDR={r.pdr:6.2f}")


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        print(f"\n--- {fn.__name__} ---")
        fn()
    print(f"\nAll {len(fns)} invariant tests passed.")
