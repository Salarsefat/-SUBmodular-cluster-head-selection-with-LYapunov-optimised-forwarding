"""
Slotted discrete-event engine.

One `run()` call simulates one (protocol, seed) pair. The Network is rebuilt
from the same seed for every protocol, so node placement, mobility
realisation, shadowing realisation, traffic pattern and initial energy are
identical across protocols -- the only difference is the routing decision.

Packets are tracked individually (birth slot in a FIFO deque per node), so
end-to-end delay, PDR and loss are exact rather than inferred from averages.
No payload aggregation is modelled: every packet is relayed store-and-forward.
This is deliberately conservative for all cluster-based schemes, including
the proposed one.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, asdict, field

import numpy as np

from .config import Config
from .network import Network
from .protocols.base import Protocol, HUB, IDLE


@dataclass
class RunResult:
    protocol: str
    seed: int
    n_nodes: int
    # delivery
    generated: int = 0
    delivered: int = 0
    dropped_buffer: int = 0
    dropped_death: int = 0
    pdr: float = 0.0
    plr: float = 0.0
    # latency / rate
    delay_mean_s: float = 0.0
    delay_p95_s: float = 0.0
    throughput_kbps: float = 0.0
    # energy
    energy_total_j: float = 0.0
    energy_per_pkt_mj: float = 0.0
    residual_mean_j: float = 0.0
    residual_norm: float = 0.0
    # lifetime (in slots; -1 => event never occurred within the horizon)
    fnd_slot: int = -1
    hnd_slot: int = -1
    lnd_slot: int = -1
    fnd_s: float = 0.0
    hnd_s: float = 0.0
    alive_end: int = 0
    # overhead / balance
    overhead_pct: float = 0.0
    ctrl_bits: float = 0.0
    data_bits: float = 0.0
    # load balance, measured at a common reference slot so that protocols
    # are compared before any of them has lost nodes (otherwise a protocol
    # that drains every node to zero scores a spurious fairness of 1.0)
    jain_energy: float = 0.0
    gini_energy: float = 0.0
    max_mean_ratio: float = 1.0
    alive_at_balance: int = 0
    residual_cv_end: float = 0.0
    jain_energy_end: float = 0.0
    reclusterings: int = 0
    tx_attempts: int = 0

    def as_dict(self) -> dict:
        return asdict(self)


def _jain(x: np.ndarray) -> float:
    x = np.asarray(x, dtype=float)
    s = x.sum()
    if s <= 0:
        return 1.0
    return float(s ** 2 / (x.size * (x ** 2).sum()))


def _gini(x: np.ndarray) -> float:
    x = np.sort(np.asarray(x, dtype=float))
    n = x.size
    if n == 0 or x.sum() <= 0:
        return 0.0
    idx = np.arange(1, n + 1)
    return float((2.0 * (idx * x).sum()) / (n * x.sum()) - (n + 1.0) / n)


def run(cfg: Config, proto_factory, seed: int) -> RunResult:
    net = Network(cfg, seed)
    rng = np.random.default_rng(seed + 10_000_007)   # decision randomness
    proto: Protocol = proto_factory(cfg, net, rng)
    N = net.N
    B = cfg.max_tx_per_slot

    queues: list[deque] = [deque() for _ in range(N)]
    qlen = np.zeros(N, dtype=int)
    gen_offset = np.random.default_rng(seed).integers(0, cfg.gen_period_slots, N)

    res = RunResult(protocol=proto.name, seed=seed, n_nodes=N)
    delays: list[int] = []
    n_alive_prev = N
    data_bits_moved = 0.0
    e_at_warmup = None
    e_at_balance = None
    idle_e = cfg.p_idle_w * cfg.slot_s * cfg.radio_duty_cycle

    for t in range(cfg.n_slots):
        # ---------------- 1. mobility & channel ----------------------
        net.move()
        if t % cfg.channel_update_slots == 0:
            net.update_channel()

        # ---------------- 2. clustering round ------------------------
        if t % cfg.slots_per_round == 0:
            proto.round_start(t, qlen.astype(float))

        # ---------------- 3. traffic generation ----------------------
        if t < cfg.gen_end_slot:
            due = np.flatnonzero(((t + gen_offset) % cfg.gen_period_slots == 0)
                                 & net.alive)
            counted = t >= cfg.warmup_slots
            for i in due:
                if qlen[i] < cfg.queue_cap:
                    queues[i].append(t)
                    qlen[i] += 1
                elif counted:
                    res.dropped_buffer += 1
                if counted:
                    res.generated += 1

        # ---------------- 4. routing decision ------------------------
        hol = np.zeros(N, dtype=int)
        act = np.flatnonzero(qlen > 0)
        for i in act:
            hol[i] = t - queues[i][0]
        nh, txmask = proto.select_next_hops(t, qlen.astype(float), hol)
        txmask = txmask & net.alive & (qlen > 0) & (nh != IDLE)
        tx = np.flatnonzero(txmask)

        e_used = np.zeros(N)
        ok_flags = np.zeros(tx.size, dtype=float)

        if tx.size:
            # ------------- 5. MAC contention -------------------------
            rx_pos = np.where((nh[tx] >= 0)[:, None],
                              net.pos[np.maximum(nh[tx], 0)], net.hub[None, :])
            d_rt = np.linalg.norm(rx_pos[:, None, :] - net.pos[tx][None, :, :],
                                  axis=-1)
            near = d_rt <= cfg.interference_radius_m
            g = proto.tdma_group[tx]
            same = (g[:, None] == g[None, :]) & (g[:, None] >= 0)
            np.fill_diagonal(same, False)
            contenders = (near & ~same).sum(axis=1) - 1.0
            p_mac = np.exp(-cfg.mac_beta * np.maximum(contenders, 0.0))

            # ------------- 6. link success ---------------------------
            to_hub = nh[tx] == HUB
            rho = np.where(to_hub, net.prr_hub[tx],
                           net.prr[tx, np.maximum(nh[tx], 0)])
            p = np.clip(rho * p_mac, 0.0, 1.0)
            dist = np.where(to_hub, net.dist_hub[tx],
                            net.dist[tx, np.maximum(nh[tx], 0)])
            e_tx1 = net.e_tx(dist, cfg.data_bits, to_hub=to_hub)
            e_rx1 = net.e_rx(cfg.data_bits)
            M = 1 + cfg.max_retx

            for k, i in enumerate(tx):
                n_send = min(B, qlen[i])
                succ_any = 0.0
                for _ in range(n_send):
                    pi = p[k]
                    if pi <= 1e-9:
                        att, good = M, False
                    else:
                        u = rng.random()
                        att = int(np.ceil(np.log(max(1e-300, 1.0 - u))
                                          / np.log(max(1e-12, 1.0 - pi))))
                        good = att <= M
                        att = min(att, M)
                    res.tx_attempts += att
                    e_used[i] += att * e_tx1[k]
                    j = nh[i]
                    if j >= 0:
                        e_used[j] += att * e_rx1
                        if proto.aggregates:
                            e_used[j] += net.e_agg(cfg.data_bits, 1)
                    if not good:
                        break                       # FIFO head-of-line block
                    birth = queues[i].popleft()
                    qlen[i] -= 1
                    data_bits_moved += cfg.data_bits
                    succ_any = 1.0
                    in_win = cfg.warmup_slots <= birth < cfg.gen_end_slot
                    if j == HUB:
                        if in_win:
                            res.delivered += 1
                            delays.append(t - birth)
                    elif qlen[j] < cfg.queue_cap:
                        queues[j].append(birth)
                        qlen[j] += 1
                    elif in_win:
                        res.dropped_buffer += 1
                ok_flags[k] = succ_any

        # ---------------- 7. idle listening --------------------------
        alive_idx = np.flatnonzero(net.alive)
        if alive_idx.size:
            e_used[alive_idx] += idle_e

        net.drain(np.arange(N), e_used)
        proto.on_result(tx, nh[tx] if tx.size else np.array([], dtype=int),
                        ok_flags, e_used)

        if t == cfg.balance_slot and e_at_warmup is not None:
            e_at_balance = np.maximum(e_at_warmup - net.energy, 0.0)
            res.alive_at_balance = int(net.alive.sum())
        if t == cfg.warmup_slots:
            e_at_warmup = net.energy.copy()
            proto.ctrl_bits_total = 0.0
            data_bits_moved = 0.0

        # ---------------- 8. lifetime bookkeeping --------------------
        n_alive = int(net.alive.sum())
        if n_alive < n_alive_prev:
            dead_now = np.flatnonzero(~net.alive)
            for i in dead_now:
                if qlen[i]:
                    res.dropped_death += sum(
                        1 for b in queues[i]
                        if cfg.warmup_slots <= b < cfg.gen_end_slot)
                    queues[i].clear()
                    qlen[i] = 0
            if res.fnd_slot < 0:
                res.fnd_slot = t
            if res.hnd_slot < 0 and n_alive <= N // 2:
                res.hnd_slot = t
            if res.lnd_slot < 0 and n_alive == 0:
                res.lnd_slot = t
            n_alive_prev = n_alive
        if n_alive == 0:
            break

    # ---------------------- final metrics ----------------------------
    res.pdr = 100.0 * res.delivered / max(res.generated, 1)
    res.plr = 100.0 - res.pdr
    if delays:
        d = np.asarray(delays, dtype=float) * cfg.slot_s
        res.delay_mean_s = float(d.mean())
        res.delay_p95_s = float(np.percentile(d, 95))
    res.throughput_kbps = (res.delivered * cfg.data_bits) / cfg.measure_time_s / 1e3
    base = e_at_warmup if e_at_warmup is not None else np.full(N, cfg.e0_j)
    consumed = np.maximum(base - net.energy, 0.0)
    res.energy_total_j = float(consumed.sum())
    res.energy_per_pkt_mj = 1e3 * res.energy_total_j / max(res.delivered, 1)
    res.residual_mean_j = float(net.energy.mean())
    res.residual_norm = 100.0 * res.residual_mean_j / cfg.e0_j
    res.alive_end = int(net.alive.sum())
    res.fnd_s = (res.fnd_slot if res.fnd_slot >= 0 else cfg.n_slots) * cfg.slot_s
    res.hnd_s = (res.hnd_slot if res.hnd_slot >= 0 else cfg.n_slots) * cfg.slot_s
    res.ctrl_bits = float(proto.ctrl_bits_total)
    res.data_bits = float(data_bits_moved)
    res.overhead_pct = 100.0 * res.ctrl_bits / max(res.ctrl_bits + res.data_bits, 1.0)
    bal = e_at_balance if e_at_balance is not None else consumed
    res.jain_energy = _jain(bal)
    res.gini_energy = _gini(bal)
    res.max_mean_ratio = float(bal.max() / max(bal.mean(), 1e-12))
    res.jain_energy_end = _jain(consumed)
    res.residual_cv_end = float(net.energy.std() / max(net.energy.mean(), 1e-12))
    res.reclusterings = int(getattr(proto, "n_reclusterings", 0))
    return res
