"""
Physical layer of the study: deployment, mobility, channel, energy.

This module is protocol-agnostic. Every routing protocol sees exactly the
same Network object built from the same (config, seed) pair, which is what
makes the comparison controlled.
"""
from __future__ import annotations

import numpy as np

from .config import Config


class Network:
    """Node placement, reference-point group mobility, channel and energy."""

    def __init__(self, cfg: Config, seed: int):
        self.cfg = cfg
        self.rng = np.random.default_rng(seed)
        n_b, n_s = cfg.n_patients, cfg.sensors_per_body
        self.N = cfg.n_nodes

        # --- patient (body) reference points, random waypoint -----------
        self.body_pos = self.rng.uniform(1.0, cfg.area_m - 1.0, size=(n_b, 2))
        self.body_dst = self.rng.uniform(1.0, cfg.area_m - 1.0, size=(n_b, 2))
        self.body_spd = self.rng.uniform(cfg.v_min_ms, cfg.v_max_ms, size=n_b)
        self.body_pause = np.zeros(n_b, dtype=int)

        # --- on-body sensor offsets (fixed body frame) ------------------
        ang = self.rng.uniform(0, 2 * np.pi, size=(n_b, n_s))
        rad = cfg.body_radius_m * np.sqrt(self.rng.uniform(0.05, 1.0, size=(n_b, n_s)))
        self.offset = np.stack([rad * np.cos(ang), rad * np.sin(ang)], axis=-1)
        self.body_of = np.repeat(np.arange(n_b), n_s)          # node -> body

        # --- node state -------------------------------------------------
        self.pos = np.zeros((self.N, 2))
        self._refresh_positions()
        self.energy = np.full(self.N, cfg.e0_j, dtype=float)
        self.alive = np.ones(self.N, dtype=bool)

        # critical (emergency-traffic) nodes
        n_crit = max(1, int(round(cfg.emergency_frac * self.N)))
        self.critical = np.zeros(self.N, dtype=bool)
        self.critical[self.rng.choice(self.N, n_crit, replace=False)] = True

        self.hub = np.asarray(cfg.hub_xy, dtype=float)

        # channel caches
        self.prr = np.zeros((self.N, self.N))
        self.prr_hub = np.zeros(self.N)
        self.dist = np.zeros((self.N, self.N))
        self.dist_hub = np.zeros(self.N)
        self.update_channel()

    # ==================================================================
    # Mobility
    # ==================================================================
    def _refresh_positions(self) -> None:
        cfg = self.cfg
        base = self.body_pos[self.body_of]
        off = self.offset.reshape(-1, 2)
        jit = self.rng.normal(0.0, cfg.body_jitter_m, size=(self.N, 2))
        self.pos = np.clip(base + off + jit, 0.0, cfg.area_m)

    def move(self) -> None:
        """One slot of reference-point group mobility."""
        cfg = self.cfg
        step = self.body_spd * cfg.slot_s
        d = self.body_dst - self.body_pos
        dn = np.linalg.norm(d, axis=1)

        moving = (self.body_pause == 0) & (dn > 1e-9)
        adv = np.minimum(step[moving], dn[moving])
        self.body_pos[moving] += (d[moving] / dn[moving, None]) * adv[:, None]

        self.body_pause[self.body_pause > 0] -= 1
        arrived = (np.linalg.norm(self.body_dst - self.body_pos, axis=1) < 1e-6)
        k = int(arrived.sum())
        if k:
            self.body_dst[arrived] = self.rng.uniform(1.0, cfg.area_m - 1.0, (k, 2))
            self.body_spd[arrived] = self.rng.uniform(cfg.v_min_ms, cfg.v_max_ms, k)
            self.body_pause[arrived] = cfg.pause_slots
        self._refresh_positions()

    # ==================================================================
    # Channel
    # ==================================================================
    def path_loss_db(self, d: np.ndarray | float) -> np.ndarray:
        """Mean log-distance path loss [dB]."""
        cfg = self.cfg
        d = np.maximum(np.asarray(d, dtype=float), cfg.d0_m)
        return cfg.pl0_db + 10.0 * cfg.path_loss_exp * np.log10(d / cfg.d0_m)

    def tx_power_dbm(self, d: np.ndarray | float,
                     gain_db: float = 0.0) -> np.ndarray:
        """Power the controller selects for distance d, capped at P_max."""
        cfg = self.cfg
        need = (cfg.snr_target_db + cfg.noise_floor_dbm
                + self.path_loss_db(d) - gain_db)
        return np.minimum(need, cfg.p_max_dbm)

    def _prr_from_distance(self, d: np.ndarray, shadow: np.ndarray,
                           gain_db: float = 0.0) -> np.ndarray:
        """Power-controlled link -> achieved SNR -> DPSK BER -> PRR."""
        cfg = self.cfg
        ptx = self.tx_power_dbm(d, gain_db)
        pl = self.path_loss_db(d) + shadow
        snr_db = ptx + gain_db - pl - cfg.noise_floor_dbm
        snr = np.power(10.0, np.clip(snr_db, -40.0, 60.0) / 10.0)
        ber = 0.5 * np.exp(-0.5 * snr)                       # non-coherent DPSK
        ber = np.clip(ber, 1e-12, 0.5)
        prr = np.exp(cfg.data_bits * np.log1p(-ber))
        return np.clip(prr, 0.0, 1.0)

    def update_channel(self) -> None:
        cfg = self.cfg
        diff = self.pos[:, None, :] - self.pos[None, :, :]
        self.dist = np.sqrt((diff ** 2).sum(-1))
        np.fill_diagonal(self.dist, np.inf)
        self.dist_hub = np.linalg.norm(self.pos - self.hub, axis=1)

        sh = self.rng.normal(0.0, cfg.shadow_sigma_db, size=(self.N, self.N))
        sh = 0.5 * (sh + sh.T)                                # reciprocal links
        self.prr = self._prr_from_distance(self.dist, sh)
        np.fill_diagonal(self.prr, 0.0)
        self.prr_hub = self._prr_from_distance(
            self.dist_hub, self.rng.normal(0.0, cfg.shadow_sigma_db, self.N),
            gain_db=cfg.hub_gain_db)

        dead = ~self.alive
        self.prr[dead, :] = 0.0
        self.prr[:, dead] = 0.0
        self.prr_hub[dead] = 0.0

    # ==================================================================
    # Energy
    # ==================================================================
    def e_tx(self, d: np.ndarray | float, bits: int,
             to_hub: bool | np.ndarray = False) -> np.ndarray | float:
        """E_TX(l,d) = l * (E_elec + c_amp * 10^(P_tx(d)/10))."""
        cfg = self.cfg
        gain = np.where(np.asarray(to_hub), cfg.hub_gain_db, 0.0)
        ptx = self.tx_power_dbm(d, gain)
        mw = np.power(10.0, ptx / 10.0)
        return bits * (cfg.e_elec_j_bit + cfg.amp_j_bit_per_mw * mw)

    def e_rx(self, bits: int) -> float:
        return bits * self.cfg.e_elec_j_bit

    def e_agg(self, bits: int, n_sig: int) -> float:
        return bits * self.cfg.e_da_j_bit * n_sig

    def drain(self, idx, amount) -> None:
        """Subtract energy and mark newly-depleted nodes as dead."""
        np.subtract.at(self.energy, idx, amount)
        np.maximum(self.energy, 0.0, out=self.energy)
        newly = self.alive & (self.energy <= 0.0)
        if newly.any():
            self.alive[newly] = False

    # ==================================================================
    # Helpers
    # ==================================================================
    def neighbours_towards_hub(self, prr_min: float = 0.35) -> list[np.ndarray]:
        """Candidate forwarders: alive, reliable, strictly closer to the hub."""
        closer = self.dist_hub[None, :] < self.dist_hub[:, None]
        ok = (self.prr >= prr_min) & closer & self.alive[None, :]
        return [np.flatnonzero(ok[i]) for i in range(self.N)]

    def hub_potential(self, prr: np.ndarray, prr_hub: np.ndarray) -> np.ndarray:
        """Most-reliable-path potential pi_i to the gateway (Dijkstra on -log rho).

        pi_i = max over paths P from i to the hub of prod_{(a,b) in P} rho_ab,
        discounted by exp(-hop_penalty) per hop.  Returned as pi in (0, 1].
        """
        import heapq
        cfg = self.cfg
        eps = 1e-12
        w_hub = -np.log(np.maximum(prr_hub, eps)) + cfg.hop_penalty
        cost = np.where(self.alive, w_hub, np.inf)
        W = -np.log(np.maximum(prr, eps)) + cfg.hop_penalty
        heap = [(float(cost[i]), int(i)) for i in np.flatnonzero(np.isfinite(cost))]
        heapq.heapify(heap)
        done = np.zeros(self.N, dtype=bool)
        while heap:
            c, j = heapq.heappop(heap)
            if done[j] or c > cost[j] + 1e-12:
                continue
            done[j] = True
            cand = W[:, j] + c
            better = np.flatnonzero(self.alive & (cand < cost - 1e-12) & ~done)
            for i in better:
                cost[i] = cand[i]
                heapq.heappush(heap, (float(cost[i]), int(i)))
        return np.exp(-np.minimum(cost, 60.0))
