"""
Benchmark protocols, re-implemented from their published descriptions.

  DTx        direct single-hop transmission (lower reference bound)
  LEACH      Heinzelman et al., HICSS 2000 -- randomised CH rotation
  SIMPLE     Nadeem et al., BWCCA 2013 -- residual-energy / distance cost
  M_ATTEMPT  Javaid et al., Procedia CS 19:224-231, 2013 -- hotspot-avoiding
             minimum-hop routing with periodic route re-discovery
  EHCRP      Khan et al., Sensors 20(21):6267, 2020 -- multi-parameter
             cooperative path cost.  The published cost is over residual
             energy, hops to sink, node congestion, SNR and available
             bandwidth; congestion and bandwidth are replaced here by a
             mobility and a link-quality term (deviation stated in the paper)
  QQAR       Arafat et al., Internet of Things 26:101151, 2024 -- Q-learning
             QoS-aware routing

These are faithful re-implementations of the published *decision rules*, not
of the authors' original code (none of which is public). They are documented
as such in the paper. All of them run on the identical Network object, the
identical traffic, and the identical seed as the proposed protocol.
"""
from __future__ import annotations

import numpy as np

from .base import Protocol, HUB, IDLE


# ======================================================================
# 1. Direct transmission
# ======================================================================
class DTx(Protocol):
    name = "DTx"

    def select_next_hops(self, t, queues, hol_age):
        nh = np.full(self.N, HUB, dtype=int)
        tx = (queues > 0) & self.net.alive
        return nh, tx


# ======================================================================
# 2. LEACH
# ======================================================================
class LEACH(Protocol):
    name = "LEACH"
    aggregates = True

    def __init__(self, cfg, net, rng):
        super().__init__(cfg, net, rng)
        self.p = cfg.ch_fraction
        self.last_ch_round = np.full(self.N, -10 ** 6, dtype=int)
        self.is_ch = np.zeros(self.N, dtype=bool)
        self.head_of = np.full(self.N, HUB, dtype=int)
        self.round = 0

    def round_start(self, t, queues=None):
        super().round_start(t, queues)
        cfg, net = self.cfg, self.net
        self.round += 1
        r, p = self.round, self.p
        period = max(int(round(1.0 / p)), 1)
        eligible = net.alive & (self.round - self.last_ch_round >= period)

        denom = 1.0 - p * (r % period)
        thr = p / denom if denom > 1e-9 else 1.0
        draw = self.rng.random(self.N)
        self.is_ch = eligible & (draw < thr)
        if not self.is_ch.any():                      # guarantee >=1 CH
            cand = np.flatnonzero(net.alive)
            if cand.size:
                self.is_ch[self.rng.choice(cand)] = True
        self.last_ch_round[self.is_ch] = self.round

        chs = np.flatnonzero(self.is_ch)
        self.head_of = np.full(self.N, HUB, dtype=int)
        if chs.size:
            members = np.flatnonzero(net.alive & ~self.is_ch)
            if members.size:
                best = np.argmax(self.link_est[np.ix_(members, chs)], axis=1)
                self.head_of[members] = chs[best]
        # CH advertisement + member join + TDMA schedule
        self.charge_control(chs, net.dist_hub[chs], listeners=max(self.N / 8, 1))
        mem = np.flatnonzero(self.head_of >= 0)
        if mem.size:
            d = net.dist[mem, self.head_of[mem]]
            self.charge_control(mem, d, listeners=1.0, frames=2.0)
        self.tdma_group = np.where(self.head_of >= 0, self.head_of,
                                   np.where(self.is_ch, np.arange(self.N), -1))

    def select_next_hops(self, t, queues, hol_age):
        nh = np.where(self.head_of >= 0, self.head_of, HUB)
        tx = (queues > 0) & self.net.alive
        return nh, tx


# ======================================================================
# 3. SIMPLE
# ======================================================================
class SIMPLE(Protocol):
    name = "SIMPLE"

    def __init__(self, cfg, net, rng):
        super().__init__(cfg, net, rng)
        self.fwd = np.full(self.N, HUB, dtype=int)

    def round_start(self, t, queues=None):
        super().round_start(t, queues)
        net, cfg = self.net, self.cfg
        e = self._norm_energy()
        # C(j) = d(j, hub) / E_res(j)   -- minimised over eligible forwarders
        cost = net.dist_hub / np.maximum(e, 1e-6)
        self.fwd = np.full(self.N, HUB, dtype=int)
        closer = net.dist_hub[None, :] < net.dist_hub[:, None]
        feasible = closer & (self.link_est >= cfg.prr_min_route) & net.alive[None, :]
        for i in np.flatnonzero(net.alive):
            if net.critical[i]:                       # critical nodes -> direct
                continue
            cand = np.flatnonzero(feasible[i])
            if cand.size:
                self.fwd[i] = cand[np.argmin(cost[cand])]
        alive = self._alive()
        self.charge_control(alive, np.full(alive.size, 2.0), listeners=3.0)

    def select_next_hops(self, t, queues, hol_age):
        tx = (queues > 0) & self.net.alive
        return self.fwd.copy(), tx


# ======================================================================
# 4. M-ATTEMPT
# ======================================================================
class M_ATTEMPT(Protocol):
    name = "M-ATTEMPT"

    def __init__(self, cfg, net, rng):
        super().__init__(cfg, net, rng)
        self.fwd = np.full(self.N, HUB, dtype=int)
        self.load = np.zeros(self.N)
        self.round = 0

    def round_start(self, t, queues=None):
        super().round_start(t, queues)
        net, cfg = self.net, self.cfg
        self.round += 1
        if (self.round - 1) % cfg.mattempt_rediscover_rounds:
            return
        # hotspot flag: most heavily loaded nodes are avoided
        alive = self._alive()
        if alive.size == 0:
            return
        thr = np.quantile(self.load[alive], cfg.mattempt_hotspot_q)
        hot = self.load > max(thr, 1e-9)

        closer = net.dist_hub[None, :] < net.dist_hub[:, None]
        feasible = closer & (self.link_est >= cfg.prr_min_route) & net.alive[None, :] & ~hot[None, :]
        self.fwd = np.full(self.N, HUB, dtype=int)
        for i in alive:
            if net.critical[i]:
                continue
            cand = np.flatnonzero(feasible[i])
            if cand.size == 0:
                cand = np.flatnonzero(closer[i] & (self.link_est[i] >= cfg.prr_min_route)
                                      & net.alive)
            if cand.size:
                self.fwd[i] = cand[np.argmin(net.dist_hub[cand])]
        self.load *= 0.5
        # flooding-based route re-discovery is the dominant overhead term
        self.charge_control(alive, np.full(alive.size, 3.0),
                            listeners=6.0, frames=2.0)

    def select_next_hops(self, t, queues, hol_age):
        tx = (queues > 0) & self.net.alive
        nh = self.fwd.copy()
        recv = nh[tx & (nh >= 0)]
        if recv.size:
            np.add.at(self.load, recv, 1.0)
        return nh, tx


# ======================================================================
# 5. EHCRP-style multi-parameter cooperative routing
# ======================================================================
class EHCRP(Protocol):
    name = "EHCRP"

    def __init__(self, cfg, net, rng):
        super().__init__(cfg, net, rng)
        self.fwd = np.full(self.N, HUB, dtype=int)
        self.prev_pos = net.pos.copy()

    def round_start(self, t, queues=None):
        super().round_start(t, queues)
        net, cfg = self.net, self.cfg
        w1, w2, w3, w4 = cfg.ehcrp_w
        e = self._norm_energy()
        mob = np.linalg.norm(net.pos - self.prev_pos, axis=1)
        mob = mob / max(mob.max(), 1e-9)
        self.prev_pos = net.pos.copy()
        hops = net.dist_hub / max(net.dist_hub.max(), 1e-9)

        closer = net.dist_hub[None, :] < net.dist_hub[:, None]
        feasible = closer & (self.link_est >= cfg.prr_min_route) & net.alive[None, :]
        base = w1 * (1.0 - e) + w2 * hops + w4 * mob
        self.fwd = np.full(self.N, HUB, dtype=int)
        for i in np.flatnonzero(net.alive):
            cand = np.flatnonzero(feasible[i])
            if cand.size:
                cost = base[cand] + w3 * (1.0 - self.link_est[i, cand])
                self.fwd[i] = cand[np.argmin(cost)]
        alive = self._alive()
        self.charge_control(alive, np.full(alive.size, 2.5),
                            listeners=4.0, frames=1.5)

    def select_next_hops(self, t, queues, hol_age):
        tx = (queues > 0) & self.net.alive
        return self.fwd.copy(), tx


# ======================================================================
# 6. QQAR-style Q-learning QoS-aware routing
# ======================================================================
class QQAR(Protocol):
    name = "QQAR"

    def __init__(self, cfg, net, rng):
        super().__init__(cfg, net, rng)
        self.Q = np.zeros((self.N, self.N + 1))       # last column = hub
        self.cand: list[np.ndarray] = []
        self._rebuild()

    def _rebuild(self):
        net = self.net
        closer = net.dist_hub[None, :] < net.dist_hub[:, None]
        ok = closer & (self.link_est >= self.cfg.prr_min_route) & net.alive[None, :]
        self.cand = [np.append(np.flatnonzero(ok[i]), self.N)
                     for i in range(self.N)]

    def round_start(self, t, queues=None):
        super().round_start(t, queues)
        self._rebuild()
        alive = self._alive()
        # Q-value piggybacking in periodic beacons
        self.charge_control(alive, np.full(alive.size, 2.0), listeners=4.0)

    def select_next_hops(self, t, queues, hol_age):
        net, cfg = self.net, self.cfg
        nh = np.full(self.N, HUB, dtype=int)
        tx = (queues > 0) & net.alive
        for i in np.flatnonzero(tx):
            c = self.cand[i]
            if c.size == 0:
                nh[i] = HUB
                continue
            if self.rng.random() < cfg.qqar_eps:
                a = int(self.rng.choice(c))
            else:
                a = int(c[np.argmax(self.Q[i, c])])
            nh[i] = HUB if a == self.N else a
        self._last_nh = nh
        return nh, tx

    def on_result(self, tx, nh, ok, energy_used):
        super().on_result(tx, nh, ok, energy_used)
        cfg, net = self.cfg, self.net
        e = self._norm_energy()
        for i, j, s in zip(tx, nh, ok):
            a = self.N if j == HUB else j
            if a == self.N:
                r = 1.2 * s - 0.5 * (net.dist_hub[i] / self.cfg.area_m)
                nxt = 0.0
            else:
                r = (0.5 * e[j] + 0.5 * s
                     - 0.3 * (net.dist_hub[j] / self.cfg.area_m) - 0.05)
                c = self.cand[j]
                nxt = float(self.Q[j, c].max()) if c.size else 0.0
            self.Q[i, a] = ((1 - cfg.qqar_alpha) * self.Q[i, a]
                            + cfg.qqar_alpha * (r + cfg.qqar_gamma * nxt))


REGISTRY = {p.name: p for p in (DTx, LEACH, SIMPLE, M_ATTEMPT, EHCRP, QQAR)}
