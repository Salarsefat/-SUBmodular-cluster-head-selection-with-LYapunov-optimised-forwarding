"""
Common interface implemented by every routing protocol in the study.

Contract
--------
round_start(t)        called at every clustering-round boundary; the protocol
                      may re-cluster / re-discover routes here and MUST charge
                      the energy of any control frames it sends.
select_next_hops(...) called every slot; returns (next_hop, tx_mask).
                      next_hop[i] == HUB (-1) means "transmit to gateway".
on_result(...)        per-slot feedback (success / failure) for adaptive
                      protocols (link estimators, trust, Q-learning).

`tdma_group[i]` groups nodes that are TDMA-scheduled together, so the
simulator can exclude intra-group concurrency from the contention count.
A value of -1 means the node contends with everybody in range.
"""
from __future__ import annotations

import numpy as np

from ..config import Config
from ..network import Network

HUB = -1
IDLE = -2


class Protocol:
    name: str = "base"
    #: True if the protocol performs in-cluster data aggregation
    aggregates: bool = False

    def __init__(self, cfg: Config, net: Network, rng: np.random.Generator):
        self.cfg = cfg
        self.net = net
        self.rng = rng
        self.N = net.N
        self.ctrl_bits_total = 0.0
        self.tdma_group = np.full(self.N, -1, dtype=int)
        # exponentially-weighted link estimate maintained by all protocols
        self.link_est = net.prr.copy()
        self.link_est_hub = net.prr_hub.copy()

    # ------------------------------------------------------------------
    # control-plane accounting
    # ------------------------------------------------------------------
    def charge_control(self, senders: np.ndarray, dists: np.ndarray,
                       listeners: float = 1.0, frames: float = 1.0) -> None:
        """Charge `frames` control frames sent by `senders` over `dists`.

        Each frame is assumed to be received by `listeners` nodes; the
        receive cost is spread over the alive population, and every bit
        (transmitted and received) is added to the overhead counter.
        """
        senders = np.asarray(senders, dtype=int)
        if senders.size == 0:
            return
        bits = self.cfg.ctrl_bits * frames
        self.net.drain(senders, self.net.e_tx(dists, bits))

        total_rx = senders.size * listeners * self.net.e_rx(bits)
        alive = self._alive()
        if alive.size:
            self.net.drain(alive, np.full(alive.size, total_rx / alive.size))
        self.ctrl_bits_total += bits * senders.size * (1.0 + listeners)

    # ------------------------------------------------------------------
    # interface
    # ------------------------------------------------------------------
    def round_start(self, t: int, queues: np.ndarray | None = None) -> None:
        """Round boundary hook.

        Every protocol refreshes its neighbour link-quality table from the
        periodic beacon exchange (identical estimator, identical gain, for
        all protocols -- differences in the results therefore come from the
        routing rule, not from estimator quality).  Subclasses must call
        this via super().
        """
        g = self.cfg.beacon_gain
        self.link_est = (1.0 - g) * self.link_est + g * self.net.prr
        self.link_est_hub = ((1.0 - g) * self.link_est_hub
                             + g * self.net.prr_hub)
        dead = ~self.net.alive
        self.link_est[dead, :] = 0.0
        self.link_est[:, dead] = 0.0
        self.link_est_hub[dead] = 0.0

    def select_next_hops(self, t: int, queues: np.ndarray,
                         hol_age: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        raise NotImplementedError

    def on_result(self, tx: np.ndarray, nh: np.ndarray, ok: np.ndarray,
                  energy_used: np.ndarray) -> None:
        """Default: EWMA update of the link estimator from observed outcomes."""
        if len(tx) == 0:
            return
        g = self.cfg.trust_ewma
        for i, j, s in zip(tx, nh, ok):
            if j == HUB:
                self.link_est_hub[i] = (1 - g) * self.link_est_hub[i] + g * s
            elif j >= 0:
                self.link_est[i, j] = (1 - g) * self.link_est[i, j] + g * s

    # ------------------------------------------------------------------
    # shared helpers
    # ------------------------------------------------------------------
    def _alive(self) -> np.ndarray:
        return np.flatnonzero(self.net.alive)

    def _norm_energy(self) -> np.ndarray:
        return np.clip(self.net.energy / self.cfg.e0_j, 0.0, 1.0)
