"""
SUBLY -- SUBmodular cluster-head selection with LYapunov-optimised forwarding
for IoT-enabled Wireless Body Area Networks.

Two provable ingredients replace the metaheuristic machinery that dominates
the WBAN routing literature:

(A) Cluster-head selection is posed as maximisation of a monotone submodular
    facility-location utility under a cardinality constraint.  Accelerated
    (lazy) greedy therefore returns a set within (1 - 1/e) of the optimum
    [Nemhauser-Wolsey-Fisher 1978; Minoux 1978], with no tuned control
    parameters and no random restarts.

(B) Per-slot forwarding is a drift-plus-penalty decision over a data-backlog
    queue and an energy virtual queue [Neely 2010], inheriting the
    [O(1/V) energy, O(V) backlog] trade-off and queue stability of
    backpressure routing [Tassiulas-Ephremides 1992].

The two ablation switches `use_submodular` and `use_lyapunov` let the same
class reproduce every row of the ablation table in the paper.
"""
from __future__ import annotations

import heapq

import numpy as np

from .base import Protocol, HUB, IDLE


class SUBLY(Protocol):
    name = "SUBLY"
    aggregates = True

    def __init__(self, cfg, net, rng, use_submodular: bool = True,
                 use_lyapunov: bool = True):
        super().__init__(cfg, net, rng)
        self.use_submodular = use_submodular
        self.use_lyapunov = use_lyapunov

        # --- Step 2 state: link estimate + behavioural trust -------------
        self.trust = np.ones(self.N)
        self.fwd_ok = np.ones(self.N)
        self.fwd_try = np.ones(self.N)
        self.pi = net.hub_potential(self.link_est, self.link_est_hub)

        # --- Step 3/4 state --------------------------------------------
        self.is_ch = np.zeros(self.N, dtype=bool)
        self.head_of = np.full(self.N, HUB, dtype=int)
        self.ch_list = np.array([], dtype=int)

        # --- Step 5 state: energy virtual queue -------------------------
        self.Z = np.zeros(self.N)
        self.e_slot = np.zeros(self.N)          # energy spent in current slot
        self.e_bar = 1.0 / max(cfg.target_lifetime_slots, 1)

        # --- Step 7 state ----------------------------------------------
        self.rounds_since = 10 ** 6
        self.e_at_cluster = net.energy.copy()
        self.n_reclusterings = 0

        # normalisation constants for the weight function
        self.e_ref = float(net.e_tx(cfg.area_m * 0.7071, cfg.data_bits))
        self.eps_rx = float(net.e_rx(cfg.data_bits)) / self.e_ref

    # ==================================================================
    # Step 2 -- link quality and trust
    # ==================================================================
    def _update_trust(self) -> None:
        self.trust = np.clip(self.fwd_ok / np.maximum(self.fwd_try, 1e-9),
                             0.0, 1.0)
        self.pi = self.net.hub_potential(self.link_est, self.link_est_hub)

    # ==================================================================
    # Step 3 -- submodular cluster-head selection (lazy greedy)
    # ==================================================================
    def _phi(self) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """phi[i,j] (coverage of i by CH j), phi_hub[i], psi[j]."""
        net = self.net
        e = self._norm_energy()
        rho = self.link_est.copy()
        ew = e ** self.cfg.energy_exp
        phi = rho * (ew * self.trust * self.pi)[None, :]
        np.fill_diagonal(phi, 0.0)
        phi[~net.alive, :] = 0.0
        phi[:, ~net.alive] = 0.0
        phi_hub = self.link_est_hub * net.alive
        psi = ew * self.pi * self.trust * net.alive
        return phi, phi_hub, psi

    def _lazy_greedy(self, phi, phi_hub, psi, k: int) -> np.ndarray:
        """Maximise f(S) = sum_i max_{j in S u {h}} phi_ij + lam * sum_j psi_j."""
        cfg, net = self.cfg, self.net
        lam = cfg.lam_modular
        eligible = np.flatnonzero(net.alive & (self.trust >= cfg.trust_floor))
        if eligible.size == 0 or k <= 0:
            return np.array([], dtype=int)
        k = min(k, eligible.size)

        cover = phi_hub.copy()                    # coverage with S = {} u {h}
        active = net.alive

        def gain(j: int) -> float:
            g = np.maximum(phi[:, j] - cover, 0.0)
            return float(g[active].sum() + lam * psi[j])

        heap = [(-gain(j), j) for j in eligible]
        heapq.heapify(heap)
        chosen: list[int] = []
        while heap and len(chosen) < k:
            neg, j = heapq.heappop(heap)
            g = gain(j)
            if not heap or g >= -heap[0][0] - 1e-12:
                if g <= 0.0 and chosen:
                    break                         # no further improvement
                chosen.append(j)
                cover = np.maximum(cover, phi[:, j])
            else:
                heapq.heappush(heap, (-g, j))
        return np.array(chosen, dtype=int)

    # ==================================================================
    # Step 4 -- capacitated association
    # ==================================================================
    def _associate(self, phi, phi_hub) -> None:
        cfg, net = self.cfg, self.net
        chs = self.ch_list
        self.head_of = np.full(self.N, HUB, dtype=int)
        self.is_ch = np.zeros(self.N, dtype=bool)
        if chs.size == 0:
            self.tdma_group = np.full(self.N, -1, dtype=int)
            return
        self.is_ch[chs] = True

        members = np.flatnonzero(net.alive & ~self.is_ch)
        if members.size == 0:
            self.tdma_group = np.where(self.is_ch, np.arange(self.N), -1)
            return

        cap = int(np.ceil(cfg.load_slack * members.size / chs.size))
        load = np.zeros(chs.size, dtype=int)
        util = phi[np.ix_(members, chs)]                       # |M| x |S|
        order = np.argsort(-util.max(axis=1))                  # neediest first
        for m_idx in order:
            i = members[m_idx]
            pref = np.argsort(-util[m_idx])
            placed = False
            for c in pref:
                if load[c] < cap and util[m_idx, c] > 0.0:
                    self.head_of[i] = chs[c]
                    load[c] += 1
                    placed = True
                    break
            if not placed:
                self.head_of[i] = HUB       # fall back to gateway uplink
        self.tdma_group = np.where(self.head_of >= 0, self.head_of,
                                   np.where(self.is_ch, np.arange(self.N), -1))

    # ==================================================================
    # Step 7 -- event-triggered re-clustering
    # ==================================================================
    def _needs_recluster(self, queues: np.ndarray) -> bool:
        cfg, net = self.cfg, self.net
        if self.rounds_since >= cfg.reclus_max_rounds:
            return True
        if self.ch_list.size == 0:
            return True
        if not net.alive[self.ch_list].all():
            return True
        drop = (self.e_at_cluster[self.ch_list] - net.energy[self.ch_list])
        if (drop > cfg.reclus_energy_drop * cfg.e0_j).any():
            return True
        alive = self._alive()
        if alive.size and queues[alive].mean() > cfg.reclus_queue_thresh:
            return True
        return False

    def round_start(self, t: int, queues: np.ndarray | None = None) -> None:
        super().round_start(t, queues)
        cfg, net = self.cfg, self.net
        self.rounds_since += 1
        q = queues if queues is not None else np.zeros(self.N)
        self._update_trust()
        if not self._needs_recluster(q):
            self._build_candidates()
            return

        phi, phi_hub, psi = self._phi()
        n_alive = int(net.alive.sum())
        k = max(1, int(np.ceil(cfg.ch_fraction * n_alive)))
        if self.use_submodular:
            self.ch_list = self._lazy_greedy(phi, phi_hub, psi, k)
        else:                                   # ablation: random rotation
            cand = np.flatnonzero(net.alive & (self.trust >= cfg.trust_floor))
            if cand.size:
                self.ch_list = self.rng.choice(cand, min(k, cand.size),
                                               replace=False)
            else:
                self.ch_list = np.array([], dtype=int)
        self._associate(phi, phi_hub)

        self._build_candidates()
        self.rounds_since = 0
        self.n_reclusterings += 1
        self.e_at_cluster = net.energy.copy()

        # control cost: CH advertisement + member join + TDMA schedule
        if self.ch_list.size:
            self.charge_control(self.ch_list, net.dist_hub[self.ch_list],
                                listeners=max(n_alive / max(self.ch_list.size, 1), 1.0))
        mem = np.flatnonzero(self.head_of >= 0)
        if mem.size:
            self.charge_control(mem, net.dist[mem, self.head_of[mem]],
                                listeners=1.0, frames=1.0)

    # ==================================================================
    # Step 6 -- drift-plus-penalty forwarding
    # ==================================================================
    def _build_candidates(self) -> None:
        """Feasible next hops: reliable links that strictly increase the
        hub potential pi.  Members may use cluster heads or the gateway;
        cluster heads may additionally use any higher-potential relay.
        Guarantees loop-freedom because pi is strictly increasing along
        every admissible hop.
        """
        cfg, net = self.cfg, self.net
        rho_ok = (self.link_est >= cfg.prr_min_route) & net.alive[None, :]
        # strict progress in the potential field; absolute tolerance so that
        # numerically equal potentials are never treated as uphill
        uphill = self.pi[None, :] > self.pi[:, None] + 1e-12
        feas = rho_ok & uphill
        is_ch = self.is_ch
        hub_ok = self.link_est_hub >= cfg.prr_min_route

        self.cand: list[np.ndarray] = []
        for i in range(self.N):
            if not net.alive[i]:
                self.cand.append(np.array([], dtype=int))
                continue
            opts = []
            if hub_ok[i]:
                opts.append(np.array([HUB]))
            row = feas[i]
            if is_ch[i]:
                sel = np.flatnonzero(row)
            else:
                sel = np.flatnonzero(row & is_ch)
                h = self.head_of[i]
                # the member's own head is admissible only if it also satisfies
                # the potential condition -- otherwise loop-freedom is lost
                if (h >= 0 and net.alive[h] and row[h]
                        and self.link_est[i, h] >= cfg.prr_min_route):
                    sel = np.union1d(sel, [h])
                if sel.size == 0:
                    sel = np.flatnonzero(row)          # fallback: any uphill relay
            if sel.size:
                opts.append(sel)
            self.cand.append(np.unique(np.concatenate(opts)) if opts
                             else np.array([], dtype=int))

    def select_next_hops(self, t, queues, hol_age):
        cfg, net = self.cfg, self.net
        V, kap, zet = cfg.V, cfg.kappa, cfg.zeta
        nh = np.full(self.N, IDLE, dtype=int)
        tx = np.zeros(self.N, dtype=bool)
        active = np.flatnonzero((queues > 0) & net.alive)

        if not hasattr(self, "cand") or len(self.cand) != self.N:
            self._build_candidates()
        for i in active:
            cand = self.cand[i]
            if cand.size == 0:
                continue
            to_hub = cand == HUB
            jj = np.where(to_hub, 0, cand)
            d = np.where(to_hub, net.dist_hub[i], net.dist[i, jj])
            eps = net.e_tx(d, cfg.data_bits, to_hub=to_hub) / self.e_ref
            rho = np.where(to_hub, self.link_est_hub[i], self.link_est[i, jj])
            q_j = np.where(to_hub, 0.0, queues[jj])
            z_j = np.where(to_hub, 0.0, self.Z[jj])
            usable = rho > 1e-6
            if not usable.any():
                continue
            if self.use_lyapunov:
                w = ((V + zet * self.Z[i]) * eps + kap * z_j * self.eps_rx
                     - rho * (queues[i] - q_j))
            else:                                  # ablation: greedy min-energy
                w = eps / np.maximum(rho, 1e-6) - 1e-9 * (queues[i] - q_j)
            w = np.where(usable, w, np.inf)
            k = int(np.argmin(w))
            best_w, best_j = float(w[k]), int(cand[k])
            if not np.isfinite(best_w):
                continue
            urgent = hol_age[i] >= cfg.deadline_slots or net.critical[i]
            if self.use_lyapunov and best_w >= 0.0 and not urgent:
                continue                           # hold: drift does not pay
            nh[i], tx[i] = best_j, True
        return nh, tx

    # ==================================================================
    # Step 5 -- virtual queue update + trust feedback
    # ==================================================================
    def on_result(self, tx, nh, ok, energy_used):
        super().on_result(tx, nh, ok, energy_used)
        g = self.cfg.trust_ewma
        if len(tx):
            self.fwd_try[tx] = (1 - g) * self.fwd_try[tx] + g
            self.fwd_ok[tx] = (1 - g) * self.fwd_ok[tx] + g * ok
        # Z_i(t+1) = max{Z_i(t) + e_i(t)/E0 - e_bar, 0}
        self.Z = np.maximum(self.Z + energy_used / self.cfg.e0_j - self.e_bar, 0.0)
