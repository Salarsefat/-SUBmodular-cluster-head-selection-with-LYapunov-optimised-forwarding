"""
Statistical machinery for the comparison.

Because every protocol is run on the *same* seed set -- identical node
placement, mobility realisation, shadowing realisation and traffic -- the
observations are naturally paired. We therefore use paired tests, which is
both more powerful and more honest than the independent-sample tests usually
reported in this literature.

For each metric we report:
  * mean, sample standard deviation, and a Student-t 95% confidence interval
  * a paired two-sided t-test  (parametric)
  * a Wilcoxon signed-rank test (distribution-free) -- reported with its own
    statistic, never with a t-value
  * Cohen's d_z for paired samples (effect size)
  * Holm-Bonferroni adjusted p-values across the family of comparisons
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy import stats as st


@dataclass
class Summary:
    n: int
    mean: float
    sd: float
    ci_lo: float
    ci_hi: float

    def pm(self, prec: int = 2) -> str:
        return f"{self.mean:.{prec}f} $\\pm$ {self.sd:.{prec}f}"


def summarise(x, confidence: float = 0.95) -> Summary:
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = x.size
    m = float(x.mean()) if n else float("nan")
    sd = float(x.std(ddof=1)) if n > 1 else 0.0
    if n > 1:
        h = st.t.ppf(0.5 + confidence / 2.0, n - 1) * sd / np.sqrt(n)
    else:
        h = 0.0
    return Summary(n, m, sd, m - h, m + h)


@dataclass
class Comparison:
    metric: str
    baseline: str
    n_pairs: int
    mean_base: float
    mean_prop: float
    delta_pct: float
    t_stat: float
    p_ttest: float
    w_stat: float
    p_wilcoxon: float
    cohen_dz: float
    p_holm: float = float("nan")

    @property
    def verdict(self) -> str:
        p = self.p_holm if np.isfinite(self.p_holm) else self.p_wilcoxon
        if p < 0.001:
            return "***"
        if p < 0.01:
            return "**"
        if p < 0.05:
            return "*"
        return "n.s."


def paired_compare(metric: str, baseline: str, base: np.ndarray,
                   prop: np.ndarray, higher_is_better: bool = True) -> Comparison:
    base = np.asarray(base, dtype=float)
    prop = np.asarray(prop, dtype=float)
    ok = np.isfinite(base) & np.isfinite(prop)
    base, prop = base[ok], prop[ok]
    d = prop - base
    n = d.size
    if n < 2 or np.allclose(d, 0.0):
        return Comparison(metric, baseline, n, float(base.mean()),
                          float(prop.mean()), 0.0, 0.0, 1.0, 0.0, 1.0, 0.0)
    t_stat, p_t = st.ttest_rel(prop, base)
    try:
        w_stat, p_w = st.wilcoxon(prop, base, zero_method="wilcox",
                                  alternative="two-sided")
    except ValueError:
        w_stat, p_w = 0.0, 1.0
    dz = float(d.mean() / d.std(ddof=1)) if d.std(ddof=1) > 0 else 0.0
    mb = float(base.mean())
    improvement = (prop.mean() - mb) / abs(mb) * 100.0 if mb != 0 else 0.0
    if not higher_is_better:
        improvement = -improvement
    return Comparison(metric, baseline, n, mb, float(prop.mean()),
                      improvement, float(t_stat), float(p_t),
                      float(w_stat), float(p_w), dz)


def holm(comps: list[Comparison], field: str = "p_wilcoxon") -> list[Comparison]:
    """In-place Holm-Bonferroni adjustment across a family of comparisons."""
    order = sorted(range(len(comps)), key=lambda i: getattr(comps[i], field))
    m = len(comps)
    running = 0.0
    for rank, i in enumerate(order):
        p = getattr(comps[i], field)
        adj = min(1.0, (m - rank) * p)
        running = max(running, adj)
        comps[i].p_holm = running
    return comps
