"""
Central configuration for the SUBLY IoT-WBAN simulation study.

EVERY tunable parameter lives here. Nothing is hard-coded elsewhere.
Change a value here (or pass overrides to `Config(...)`) and the whole
study -- all protocols, all experiments -- follows.

All protocols receive the *same* Config instance and the *same* seed, so
node placement, initial energy, traffic, packet sizes, radio model,
mobility and channel realisations are byte-identical across protocols.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict, replace
from typing import Tuple
import json


@dataclass(frozen=True)
class Config:
    # ------------------------------------------------------------------
    # Topology / deployment
    # ------------------------------------------------------------------
    n_patients: int = 8               # number of bodies (WBANs) in the ward
    sensors_per_body: int = 8         # on-body biosensors per patient
    area_m: float = 24.0              # square ward side length [m]
    body_radius_m: float = 0.45       # on-body sensor offset radius [m]
    hub_xy: Tuple[float, float] = (12.0, 12.0)   # ceiling gateway position [m]
    hub_height_m: float = 0.0         # kept 0: planar model

    # ------------------------------------------------------------------
    # Mobility (Reference-Point Group Mobility: body moves, sensors follow)
    # ------------------------------------------------------------------
    v_max_ms: float = 1.2             # max patient walking speed [m/s]
    v_min_ms: float = 0.0
    pause_slots: int = 20             # random-waypoint pause [slots]
    body_jitter_m: float = 0.02       # per-slot on-body posture jitter s.d. [m]

    # ------------------------------------------------------------------
    # Time
    # ------------------------------------------------------------------
    slot_s: float = 0.25              # slot duration [s]
    n_slots: int = 1600               # slots per run
    warmup_slots: int = 120           # excluded from metrics (estimators settle)
    drain_slots: int = 200            # trailing window: no new packets counted
    balance_slot: int = 600           # common reference time for load balance
    slots_per_round: int = 20         # clustering round length [slots]
    channel_update_slots: int = 4     # channel coherence [slots]

    # ------------------------------------------------------------------
    # Traffic
    # ------------------------------------------------------------------
    gen_period_slots: int = 4         # CBR inter-arrival [slots] per node
    payload_bytes: int = 96           # application payload [B]
    header_bytes: int = 8             # MAC/NET header [B]
    ctrl_bytes: int = 12              # one control frame [B]
    emergency_frac: float = 0.05      # fraction of nodes marked critical
    queue_cap: int = 128              # per-node buffer [packets]

    # ------------------------------------------------------------------
    # Radio / PHY  (IEEE 802.15.6-style narrowband 2.4 GHz)
    # ------------------------------------------------------------------
    p_max_dbm: float = 0.0            # maximum transmit power [dBm]
    snr_target_db: float = 16.0       # SNR the power controller targets
    pl0_db: float = 30.0              # path loss at reference distance [dB]
    d0_m: float = 0.10                # reference distance [m]
    path_loss_exp: float = 3.2        # on-body / in-ward exponent
    shadow_sigma_db: float = 3.0      # log-normal shadowing s.d. [dB]
    noise_floor_dbm: float = -100.0   # receiver noise floor [dBm]
    hub_gain_db: float = 3.0          # gateway antenna + LNA advantage [dB]
    prr_min_route: float = 0.30       # min link PRR to be a routing candidate
    hop_penalty: float = 0.05         # -log reliability penalty per extra hop
    bitrate_bps: float = 242900.0     # 802.15.6 narrowband PHY rate [bit/s]
    prr_floor: float = 1e-4           # numerical floor on link PRR

    # ------------------------------------------------------------------
    # MAC abstraction (CSMA/CA collision model)
    # ------------------------------------------------------------------
    mac_beta: float = 0.05            # P_mac(k) = exp(-beta * (k-1))
    interference_radius_m: float = 6.0
    max_retx: int = 3                 # MAC retransmissions per packet
    max_tx_per_slot: int = 8          # packets a node may clear per slot

    # ------------------------------------------------------------------
    # Energy: power-controlled first-order radio model.  The transmitter
    # raises its power only as far as needed to close the link at
    # snr_target_db, capped at p_max_dbm, and amplifier energy is
    # proportional to the linear transmit power actually used:
    #     P_tx(d) = min(P_max, SNR* + N0 + PL(d) - G)
    #     E_TX(l,d) = l * (E_elec + c_amp * 10^(P_tx/10))
    #     E_RX(l)   = l *  E_elec
    # ------------------------------------------------------------------
    e0_j: float = 0.50                # initial node energy [J]
    e_elec_j_bit: float = 16.7e-9     # TX/RX electronics [J/bit]
    amp_j_bit_per_mw: float = 4.0e-7  # amplifier energy [J/bit per mW of P_tx]
    e_da_j_bit: float = 5e-9          # relay/aggregation processing [J/bit]
    p_idle_w: float = 1.4e-3          # radio idle/listen power [W]
    radio_duty_cycle: float = 0.01    # low-power-listening duty cycle

    # ------------------------------------------------------------------
    # Clustering (shared)
    # ------------------------------------------------------------------
    ch_fraction: float = 0.12         # target CH fraction q

    # ------------------------------------------------------------------
    # SUBLY: submodular CH selection
    # ------------------------------------------------------------------
    lam_modular: float = 0.30         # lambda: modular CH-quality weight
    energy_exp: float = 3.0           # nu: exponent on normalised residual energy
    load_slack: float = 1.02          # capacity cap slack factor
    trust_ewma: float = 0.15          # EWMA gain for trust / PRR estimate
    beacon_gain: float = 0.60         # EWMA gain of the beacon LQI refresh
    trust_floor: float = 0.35         # below this a node cannot be CH

    # ------------------------------------------------------------------
    # SUBLY: Lyapunov forwarding
    # ------------------------------------------------------------------
    V: float = 2.0                   # drift-plus-penalty weight
    kappa: float = 3.0                # receiver energy-queue weight
    zeta: float = 60.0                # sender energy-queue weight
    deadline_slots: int = 12          # HOL deadline override [slots]
    target_lifetime_slots: int = 1600 # horizon used for energy budget e_bar

    # ------------------------------------------------------------------
    # SUBLY: event-triggered re-clustering
    # ------------------------------------------------------------------
    reclus_energy_drop: float = 0.04  # trigger if CH loses this frac of E0
    reclus_queue_thresh: float = 6.0  # trigger if mean backlog exceeds this
    reclus_max_rounds: int = 12       # hard re-clustering deadline [rounds]

    # ------------------------------------------------------------------
    # Baseline-specific
    # ------------------------------------------------------------------
    qqar_alpha: float = 0.30          # Q-learning rate
    qqar_gamma: float = 0.80          # discount
    qqar_eps: float = 0.10            # exploration
    ehcrp_w: Tuple[float, float, float, float] = (0.40, 0.25, 0.25, 0.10)
    mattempt_hotspot_q: float = 0.85  # load quantile flagged as hotspot
    mattempt_rediscover_rounds: int = 2

    # ------------------------------------------------------------------
    # Experiment control
    # ------------------------------------------------------------------
    seed: int = 0
    n_seeds: int = 30
    confidence: float = 0.95

    # ---------------- derived -------------------------------------------
    @property
    def n_nodes(self) -> int:
        return self.n_patients * self.sensors_per_body

    @property
    def data_bits(self) -> int:
        return 8 * (self.payload_bytes + self.header_bytes)

    @property
    def ctrl_bits(self) -> int:
        return 8 * self.ctrl_bytes

    @property
    def sim_time_s(self) -> float:
        return self.n_slots * self.slot_s

    @property
    def gen_end_slot(self) -> int:
        """Last slot (exclusive) whose packets are counted in the metrics."""
        return self.n_slots - self.drain_slots

    @property
    def measure_time_s(self) -> float:
        return (self.gen_end_slot - self.warmup_slots) * self.slot_s

    def with_(self, **kw) -> "Config":
        return replace(self, **kw)

    def to_json(self) -> str:
        return json.dumps(asdict(self), indent=2, default=str)


DEFAULT = Config()
