"""Protocol registry: maps a name to a factory (cfg, net, rng) -> Protocol."""
from __future__ import annotations

from functools import partial

from .protocols import DTx, LEACH, SIMPLE, M_ATTEMPT, EHCRP, QQAR, SUBLY

PROTOCOLS = {
    "DTx": DTx,
    "LEACH": LEACH,
    "SIMPLE": SIMPLE,
    "M-ATTEMPT": M_ATTEMPT,
    "EHCRP": EHCRP,
    "QQAR": QQAR,
    "SUBLY": SUBLY,
}

#: ablation variants of the proposed protocol
ABLATIONS = {
    "SUBLY": partial(SUBLY, use_submodular=True, use_lyapunov=True),
    "SUBLY-noSub": partial(SUBLY, use_submodular=False, use_lyapunov=True),
    "SUBLY-noLyap": partial(SUBLY, use_submodular=True, use_lyapunov=False),
    "SUBLY-neither": partial(SUBLY, use_submodular=False, use_lyapunov=False),
}

BASELINE_ORDER = ["DTx", "LEACH", "SIMPLE", "M-ATTEMPT", "EHCRP", "QQAR", "SUBLY"]


def make(name: str):
    if name in PROTOCOLS:
        return PROTOCOLS[name]
    if name in ABLATIONS:
        return ABLATIONS[name]
    raise KeyError(f"unknown protocol {name!r}")
