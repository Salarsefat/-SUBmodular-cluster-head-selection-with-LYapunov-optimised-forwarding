#!/usr/bin/env python3
"""
Run every experiment in the study and write tidy CSVs to results/raw/.

    python scripts/run_experiments.py all
    python scripts/run_experiments.py main scalability
    python scripts/run_experiments.py --seeds 10 main

Every experiment sweeps the *identical* seed list across all protocols, so
results are paired and the statistical tests in `subly.stats` are valid.
"""
from __future__ import annotations

import argparse
import csv
import os
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "src"))

from subly import Config, run                                    # noqa: E402
from subly.registry import BASELINE_ORDER, ABLATIONS, make        # noqa: E402

RAW = os.path.join(ROOT, "results", "raw")
os.makedirs(RAW, exist_ok=True)

# ----------------------------------------------------------------------
# configuration of each experiment
# ----------------------------------------------------------------------
CFG_QOS = dict(n_slots=1600, drain_slots=200, e0_j=0.50,
               target_lifetime_slots=1600, balance_slot=600)
CFG_LIFE = dict(n_slots=2400, drain_slots=200, e0_j=0.12,
                target_lifetime_slots=2400, balance_slot=300)

N_MAIN, N_LIFE, N_SWEEP = 30, 20, 8


TAG = ""
ONLY: list[str] | None = None


def _write(rows: list[dict], name: str) -> str:
    path = os.path.join(RAW, f"{name}{TAG}.csv")
    if not rows:
        return path
    keys = list(rows[0].keys())
    with open(path, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)
    print(f"  -> {path}  ({len(rows)} rows)")
    return path


def _protos(default: list[str]) -> list[str]:
    return [p for p in default if ONLY is None or p in ONLY]


def _sweep(cfg_kw: dict, protocols, seeds, extra: dict | None = None) -> list[dict]:
    rows = []
    for name in protocols:
        for s in seeds:
            r = run(Config(**cfg_kw), make(name), seed=s)
            d = r.as_dict()
            d["protocol"] = name
            if extra:
                d.update(extra)
            rows.append(d)
    return rows


# ----------------------------------------------------------------------
def exp_main(seeds: int) -> None:
    print(f"[main] N=64, {seeds} seeds, 7 protocols")
    rows = _sweep(CFG_QOS, _protos(BASELINE_ORDER), range(seeds))
    _write(rows, "main")


def exp_lifetime(seeds: int) -> None:
    print(f"[lifetime] energy-constrained (E0=0.12 J), {seeds} seeds")
    rows = _sweep(CFG_LIFE, _protos(BASELINE_ORDER), range(seeds))
    _write(rows, "lifetime")


def exp_scalability(seeds: int) -> None:
    print(f"[scalability] N in 16..128, {seeds} seeds")
    rows = []
    for n_pat in (2, 4, 8, 12, 16):
        kw = dict(CFG_QOS, n_patients=n_pat, n_slots=1000, drain_slots=150,
                  target_lifetime_slots=1000, balance_slot=450)
        t0 = time.time()
        rows += _sweep(kw, _protos(BASELINE_ORDER), range(seeds),
                       extra={"sweep_n_nodes": n_pat * 8})
        print(f"   N={n_pat*8:4d} done in {time.time()-t0:5.1f}s")
    _write(rows, "scalability")


def exp_mobility(seeds: int) -> None:
    print(f"[mobility] v_max 0.0..2.4 m/s, {seeds} seeds")
    rows = []
    for v in (0.0, 0.6, 1.2, 1.8, 2.4):
        kw = dict(CFG_QOS, v_max_ms=v, n_slots=1200, drain_slots=150,
                  target_lifetime_slots=1200, balance_slot=500)
        rows += _sweep(kw, _protos(BASELINE_ORDER), range(seeds), extra={"sweep_v": v})
        print(f"   v={v:.1f} m/s done")
    _write(rows, "mobility")


def exp_vsweep(seeds: int) -> None:
    print(f"[vsweep] Lyapunov V trade-off, {seeds} seeds")
    rows = []
    for V in (0.25, 0.5, 1.0, 2.0, 4.0, 8.0, 16.0, 32.0):
        kw = dict(CFG_QOS, V=V, n_slots=1200, drain_slots=150,
                  target_lifetime_slots=1200, balance_slot=500)
        rows += _sweep(kw, ["SUBLY"], range(seeds), extra={"sweep_V": V})
    _write(rows, "vsweep")


def exp_ablation(seeds: int) -> None:
    print(f"[ablation] component contribution, {seeds} seeds")
    rows = _sweep(CFG_QOS, _protos(list(ABLATIONS.keys())), range(seeds))
    _write(rows, "ablation")


EXPERIMENTS = {
    "main": exp_main,
    "lifetime": exp_lifetime,
    "scalability": exp_scalability,
    "mobility": exp_mobility,
    "vsweep": exp_vsweep,
    "ablation": exp_ablation,
}
SEEDS = {"main": N_MAIN, "lifetime": N_LIFE, "scalability": N_SWEEP,
         "mobility": N_SWEEP, "vsweep": 10, "ablation": 10}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("which", nargs="*", default=["all"])
    ap.add_argument("--seeds", type=int, default=None,
                    help="override the seed count for every experiment")
    ap.add_argument("--protocols", default=None,
                    help="comma-separated subset of protocols to run")
    ap.add_argument("--tag", default="", help="suffix appended to output CSV")
    a = ap.parse_args()
    global TAG, ONLY
    TAG = a.tag
    ONLY = a.protocols.split(",") if a.protocols else None
    todo = list(EXPERIMENTS) if "all" in a.which else a.which
    for name in todo:
        if name not in EXPERIMENTS:
            raise SystemExit(f"unknown experiment {name!r}")
        t0 = time.time()
        EXPERIMENTS[name](a.seeds or SEEDS[name])
        print(f"[{name}] {time.time()-t0:.1f}s\n")


if __name__ == "__main__":
    main()
