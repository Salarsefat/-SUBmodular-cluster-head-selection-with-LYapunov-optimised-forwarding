#!/usr/bin/env python3
"""Build every LaTeX table in the paper from results/raw/*.csv."""
from __future__ import annotations

import collections
import csv
import os
import sys

import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "src"))
from subly.stats import summarise, paired_compare, holm            # noqa: E402

RAW = os.path.join(ROOT, "results", "raw")
OUT = os.path.join(ROOT, "tables")
os.makedirs(OUT, exist_ok=True)

ORDER = ["DTx", "LEACH", "SIMPLE", "M-ATTEMPT", "EHCRP", "QQAR", "SUBLY"]
NICE = {"DTx": "DTx", "LEACH": "LEACH", "SIMPLE": "SIMPLE",
        "M-ATTEMPT": "M-ATTEMPT", "EHCRP": "EHCRP", "QQAR": "QQAR",
        "SUBLY": r"\textbf{SUBLY}"}


def load(name):
    with open(os.path.join(RAW, f"{name}.csv")) as fh:
        return list(csv.DictReader(fh))


def group(rows, *keys):
    g = collections.defaultdict(list)
    for r in rows:
        g[tuple(r[k] for k in keys) if len(keys) > 1 else r[keys[0]]].append(r)
    return g


def col(rows, f):
    return np.array([float(r[f]) for r in rows])


def save(name, text):
    p = os.path.join(OUT, name)
    with open(p, "w") as fh:
        fh.write(text)
    print("  ->", p)


def save_tabular(name, colspec, header, body, pre="", post=""):
    """Emit a COMPLETE tabular so main.tex never calls \\input inside an
    alignment (which is fragile in TeX)."""
    t = [pre.rstrip(), r"\begin{tabular}{" + colspec + "}", r"\toprule"]
    t += [h for h in header]
    t += [r"\midrule", body.rstrip(), r"\bottomrule", r"\end{tabular}",
          post.rstrip()]
    save(name, "\n".join(x for x in t if x) + "\n")


# ======================================================================
# Table: main results
# ======================================================================
def table_main():
    g = group(load("main"), "protocol")
    # (field, label, precision, higher_is_better, scale)
    spec = [
        ("pdr",               r"PDR (\%)",                     2, True,  1.0),
        ("plr",               r"Packet loss (\%)",             2, False, 1.0),
        ("delay_mean_s",      r"End-to-end delay (s)",         2, False, 1.0),
        ("throughput_kbps",   r"Throughput (kb/s)",            1, True,  1.0),
        ("energy_total_j",    r"Total energy (J)",             2, False, 1.0),
        ("energy_per_pkt_mj", r"Energy per packet ($\mu$J)",   0, False, 1e3),
        ("residual_norm",     r"Avg.\ residual energy (\%)",   1, True,  1.0),
        ("alive_end",         r"Nodes alive at end",           1, True,  1.0),
        ("overhead_pct",      r"Control overhead (\%)",        2, False, 1.0),
        ("jain_energy",       r"Jain fairness index",          3, True,  1.0),
        ("max_mean_ratio",    r"Max/mean load ratio",          2, False, 1.0),
    ]
    lines = []
    for f, lab, prec, hib, sc in spec:
        vals = {p: summarise(col(g[p], f) * sc) for p in ORDER}
        best = (max if hib else min)(ORDER, key=lambda p: vals[p].mean)
        cells = []
        for p in ORDER:
            s = f"{vals[p].mean:.{prec}f}\\,$\\pm$\\,{vals[p].sd:.{prec}f}"
            cells.append(f"\\bfseries {s}" if p == best else s)
        lines.append(f"{lab} & " + " & ".join(cells) + r" \\")
    head = ["Metric & " + " & ".join(
        ["DTx", "LEACH", "SIMPLE", "M-ATTEMPT", "EHCRP", "QQAR",
         r"\textbf{SUBLY}"]) + r" \\"]
    save_tabular("main_results.tex", "@{}l" + "c" * 7 + "@{}",
                 head, "\n".join(lines))


# ======================================================================
# Table: statistical validation
# ======================================================================
def table_stats():
    g = group(load("main"), "protocol")
    metrics = [("pdr", "PDR", True), ("delay_mean_s", "Delay", False),
               ("throughput_kbps", "Throughput", True),
               ("energy_per_pkt_mj", "Energy/pkt", False),
               ("residual_norm", "Residual energy", True),
               ("overhead_pct", "Overhead", False)]
    comps, lines = [], []
    for f, lab, hib in metrics:
        prop = col(g["SUBLY"], f)
        for b in ORDER[:-1]:
            c = paired_compare(lab, b, col(g[b], f), prop, hib)
            comps.append(c)
    holm(comps, "p_wilcoxon")
    i = 0
    for f, lab, hib in metrics:
        for b in ORDER[:-1]:
            c = comps[i]; i += 1
            first = f"\\multirow{{6}}{{*}}{{{lab}}}" if b == ORDER[0] else ""
            # a zero baseline makes a relative improvement undefined: the
            # overhead comparison against DTx (which sends no control frames)
            # is degenerate and must not be presented as a significant win
            if abs(c.mean_base) < 1e-9:
                lines.append(
                    f"{first} & {b} & {c.mean_base:.2f} & {c.mean_prop:.2f} & "
                    r"n/a & --- & --- & --- & --- & --- & --- \\")
                continue
            pw = "$<$0.001" if c.p_wilcoxon < 1e-3 else f"{c.p_wilcoxon:.4f}"
            ph = "$<$0.001" if c.p_holm < 1e-3 else f"{c.p_holm:.4f}"
            mark = c.verdict
            if c.delta_pct < 0 and mark != "n.s.":
                mark = mark + r"$^{\dagger}$"
            lines.append(
                f"{first} & {b} & {c.mean_base:.2f} & {c.mean_prop:.2f} & "
                f"{c.delta_pct:+.1f} & {c.t_stat:.2f} & {c.w_stat:.0f} & "
                f"{pw} & {ph} & {c.cohen_dz:.2f} & {mark} \\\\")
        lines.append(r"\midrule")
    head = [(r"Metric & Baseline & Baseline mean & SUBLY mean & $\Delta$ (\%) "
             r"& $t$ & $W$ & $p_W$ & $p_{\mathrm{Holm}}$ & $d_z$ & Sig. \\")]
    save_tabular("stats.tex", "@{}ll" + "c" * 9 + "@{}", head,
                 "\n".join(lines[:-1]))


# ======================================================================
# Table: lifetime
# ======================================================================
def table_lifetime():
    g = group(load("lifetime"), "protocol")
    lines = []
    for p in ORDER:
        r = g[p]
        fnd, hnd = summarise(col(r, "fnd_s")), summarise(col(r, "hnd_s"))
        lnd = summarise(np.where(col(r, "lnd_slot") >= 0,
                                 col(r, "lnd_slot") * 0.25, 600.0))
        lines.append(
            f"{NICE[p]} & {fnd.mean:.1f}\\,$\\pm$\\,{fnd.sd:.1f} & "
            f"{hnd.mean:.1f}\\,$\\pm$\\,{hnd.sd:.1f} & "
            f"{lnd.mean:.1f}\\,$\\pm$\\,{lnd.sd:.1f} & "
            f"{summarise(col(r,'pdr')).mean:.2f} \\\\")
    head = [r"Protocol & FND (s) & HND (s) & LND (s) & PDR (\%) \\"]
    save_tabular("lifetime.tex", "@{}lcccc@{}", head, "\n".join(lines))


# ======================================================================
# Table: scalability
# ======================================================================
def table_scalability():
    rows = load("scalability")
    g = group(rows, "protocol", "sweep_n_nodes")
    Ns = sorted({int(r["sweep_n_nodes"]) for r in rows})
    out = []
    for p in ORDER:
        pdr = " & ".join(f"{col(g[(p,str(n))],'pdr').mean():.1f}" for n in Ns)
        e = " & ".join(f"{col(g[(p,str(n))],'energy_per_pkt_mj').mean()*1e3:.0f}"
                       for n in Ns)
        out.append(f"{NICE[p]} & {pdr} & & {e} \\\\")
    ns = " & ".join(str(n) for n in Ns)
    head = [(r"& \multicolumn{%d}{c}{PDR (\%%)} & & "
             r"\multicolumn{%d}{c}{Energy/packet ($\mu$J)} \\" % (len(Ns), len(Ns))),
            r"\cmidrule(lr){2-%d}\cmidrule(lr){%d-%d}"
            % (1 + len(Ns), 3 + len(Ns), 2 + 2 * len(Ns)),
            f"Protocol & {ns} & & {ns} " + r"\\"]
    save_tabular("scalability.tex",
                 "@{}l" + "c" * len(Ns) + "c" + "c" * len(Ns) + "@{}",
                 head, "\n".join(out))


# ======================================================================
# Table: ablation
# ======================================================================
def table_ablation():
    g = group(load("ablation"), "protocol")
    labels = {"SUBLY": r"\textbf{SUBLY} (full)",
              "SUBLY-noSub": r"$-$submodular CH (random rotation)",
              "SUBLY-noLyap": r"$-$Lyapunov (greedy min-energy)",
              "SUBLY-neither": r"$-$both"}
    lines = []
    for p in ["SUBLY", "SUBLY-noSub", "SUBLY-noLyap", "SUBLY-neither"]:
        r = g[p]
        lines.append(
            f"{labels[p]} & {col(r,'pdr').mean():.2f} & "
            f"{col(r,'delay_mean_s').mean():.2f} & "
            f"{col(r,'throughput_kbps').mean():.1f} & "
            f"{col(r,'energy_per_pkt_mj').mean()*1e3:.0f} & "
            f"{col(r,'residual_norm').mean():.1f} & "
            f"{col(r,'jain_energy').mean():.3f} \\\\")
    head = [(r"Variant & PDR & Delay & Thr. & Energy & Resid. & Jain \\"),
            (r" & (\%) & (s) & (kb/s) & ($\mu$J) & (\%) & \\")]
    save_tabular("ablation.tex", "@{}lcccccc@{}", head, "\n".join(lines))


# ======================================================================
# key numbers used in the prose
# ======================================================================
def key_numbers():
    g = group(load("main"), "protocol")
    gl = group(load("lifetime"), "protocol")
    s = col(g["SUBLY"], "energy_per_pkt_mj").mean()
    lines = [f"SUBLY PDR = {col(g['SUBLY'],'pdr').mean():.2f} "
             f"+- {col(g['SUBLY'],'pdr').std(ddof=1):.2f}"]
    for p in ORDER[:-1]:
        lines.append(
            f"vs {p:10s}: PDR {col(g['SUBLY'],'pdr').mean()-col(g[p],'pdr').mean():+.2f} pp | "
            f"energy/pkt {col(g[p],'energy_per_pkt_mj').mean()/s:.2f}x lower | "
            f"delay {col(g[p],'delay_mean_s').mean()/col(g['SUBLY'],'delay_mean_s').mean():.2f}x | "
            f"thr {col(g['SUBLY'],'throughput_kbps').mean()/col(g[p],'throughput_kbps').mean():.2f}x | "
            f"FND {col(gl['SUBLY'],'fnd_s').mean()/col(gl[p],'fnd_s').mean():.2f}x")
    save("key_numbers.txt", "\n".join(lines) + "\n")
    print("\n".join(lines))


if __name__ == "__main__":
    table_main(); table_stats(); table_lifetime()
    table_scalability(); table_ablation(); key_numbers()
