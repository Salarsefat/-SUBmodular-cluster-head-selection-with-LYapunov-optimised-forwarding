#!/usr/bin/env python3
"""Build every figure in the paper from results/raw/*.csv (vector PDF)."""
from __future__ import annotations

import collections
import csv
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy import stats as st

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAW = os.path.join(ROOT, "results", "raw")
FIG = os.path.join(ROOT, "figures")
os.makedirs(FIG, exist_ok=True)

ORDER = ["DTx", "LEACH", "SIMPLE", "M-ATTEMPT", "EHCRP", "QQAR", "SUBLY"]
MARK = {"DTx": "o", "LEACH": "s", "SIMPLE": "^", "M-ATTEMPT": "v",
        "EHCRP": "D", "QQAR": "P", "SUBLY": "*"}
GREY = {"DTx": "0.55", "LEACH": "0.40", "SIMPLE": "0.62", "M-ATTEMPT": "0.30",
        "EHCRP": "0.72", "QQAR": "0.48", "SUBLY": "black"}

plt.rcParams.update({
    "font.size": 8, "axes.labelsize": 8, "axes.titlesize": 8.5,
    "legend.fontsize": 6.6, "xtick.labelsize": 7, "ytick.labelsize": 7,
    "figure.dpi": 200, "savefig.bbox": "tight", "savefig.pad_inches": 0.02,
    "axes.grid": True, "grid.alpha": 0.3, "grid.linewidth": 0.4,
    "lines.linewidth": 1.2, "lines.markersize": 4.2,
    "axes.spines.top": False, "axes.spines.right": False,
})
W1, W2 = 3.35, 7.0            # single- and double-column widths [in]


def load(n):
    with open(os.path.join(RAW, f"{n}.csv")) as fh:
        return list(csv.DictReader(fh))


def group(rows, *keys):
    g = collections.defaultdict(list)
    for r in rows:
        g[tuple(r[k] for k in keys) if len(keys) > 1 else r[keys[0]]].append(r)
    return g


def col(rows, f):
    return np.array([float(r[f]) for r in rows])


def ci95(x):
    x = np.asarray(x, float)
    if x.size < 2:
        return 0.0
    return st.t.ppf(0.975, x.size - 1) * x.std(ddof=1) / np.sqrt(x.size)


def bars(ax, g, field, ylabel, scale=1.0, log=False):
    m = [col(g[p], field).mean() * scale for p in ORDER]
    e = [ci95(col(g[p], field) * scale) for p in ORDER]
    ax.bar(range(len(ORDER)), m, yerr=e, capsize=2.2, width=0.68,
           color=[GREY[p] for p in ORDER], edgecolor="black", linewidth=0.5)
    ax.set_xticks(range(len(ORDER)))
    ax.set_xticklabels(ORDER, rotation=32, ha="right")
    ax.set_ylabel(ylabel)
    if log:
        ax.set_yscale("log")
    return m


def shared_legend(fig, ncol=7, y=-0.02):
    handles = [plt.Line2D([], [], marker=MARK[p], color=GREY[p],
                          lw=1.8 if p == "SUBLY" else 1.0, label=p)
               for p in ORDER]
    fig.legend(handles=handles, loc="lower center", ncol=ncol, frameon=False,
               bbox_to_anchor=(0.5, y), fontsize=6.6, columnspacing=1.1,
               handlelength=1.6)


def save(fig, name):
    p = os.path.join(FIG, name)
    # Suppress the non-semantic /CreationDate so repeated runs on identical
    # input produce byte-identical PDFs (matplotlib writes wall-clock time by
    # default, which makes every regeneration look like a diff in git).
    fig.savefig(p, metadata={"CreationDate": None})
    plt.close(fig)
    print("  ->", p)


# ======================================================================
def fig_qos_energy():
    """Six primary QoS/energy panels, full text width (figure*)."""
    g = group(load("main"), "protocol")
    fig, ax = plt.subplots(2, 3, figsize=(W2, 3.75))
    bars(ax[0, 0], g, "pdr", "Packet delivery ratio (%)")
    ax[0, 0].set_ylim(0, 108); ax[0, 0].axhline(95, ls="--", c="k", lw=0.7)
    ax[0, 0].text(0.05, 96.6, "95% target", fontsize=6)
    bars(ax[0, 1], g, "plr", "Packet loss ratio (%)")
    bars(ax[0, 2], g, "throughput_kbps", "Throughput (kb/s)")
    bars(ax[1, 0], g, "delay_mean_s", "Mean end-to-end delay (s)")
    bars(ax[1, 1], g, "energy_per_pkt_mj", r"Energy per packet ($\mu$J)", 1e3)
    bars(ax[1, 2], g, "residual_norm", "Avg. residual energy (%)")
    for a_, t in zip(ax.ravel(), "(a) (b) (c) (d) (e) (f)".split()):
        a_.set_title(t, loc="left", fontsize=8)
    fig.tight_layout()
    save(fig, "fig_qos_energy.pdf")


def fig_overhead_balance():
    g = group(load("main"), "protocol")
    fig, ax = plt.subplots(1, 2, figsize=(W1, 2.05))
    bars(ax[0], g, "overhead_pct", "Control overhead (%)")
    bars(ax[1], g, "jain_energy", "Jain index")
    ax[1].set_ylim(0.4, 1.0)
    for a, t in zip(ax, "(a) (b)".split()):
        a.set_title(t, loc="left", fontsize=8)
    fig.tight_layout()
    save(fig, "fig_overhead_balance.pdf")


def fig_lifetime():
    g = group(load("lifetime"), "protocol")
    fig, ax = plt.subplots(figsize=(W1, 2.1))
    x = np.arange(len(ORDER)); w = 0.27
    for k, (f, lab, hatch) in enumerate([
            ("fnd_s", "FND", ""), ("hnd_s", "HND", "//"), ("lnd", "LND", "xx")]):
        if f == "lnd":
            v = [np.where(col(g[p], "lnd_slot") >= 0,
                          col(g[p], "lnd_slot") * 0.25, 600.0) for p in ORDER]
        else:
            v = [col(g[p], f) for p in ORDER]
        ax.bar(x + (k - 1) * w, [a.mean() for a in v], w,
               yerr=[ci95(a) for a in v], capsize=1.6, label=lab,
               color=["0.85", "0.6", "0.35"][k], edgecolor="black",
               linewidth=0.45, hatch=hatch)
    ax.set_xticks(x); ax.set_xticklabels(ORDER, rotation=32, ha="right")
    ax.set_ylabel("Time (s)")
    ax.legend(ncol=3, frameon=False, loc="upper left")
    save(fig, "fig_lifetime.pdf")


def fig_scalability():
    rows = load("scalability")
    g = group(rows, "protocol", "sweep_n_nodes")
    Ns = sorted({int(r["sweep_n_nodes"]) for r in rows})
    fig, ax = plt.subplots(1, 3, figsize=(W2, 2.1))
    for p in ORDER:
        pdr = [col(g[(p, str(n))], "pdr").mean() for n in Ns]
        err = [ci95(col(g[(p, str(n))], "pdr")) for n in Ns]
        ax[0].errorbar(Ns, pdr, yerr=err, marker=MARK[p], color=GREY[p],
                       label=p, capsize=1.6,
                       lw=1.8 if p == "SUBLY" else 1.0)
        ax[1].plot(Ns, [col(g[(p, str(n))], "energy_per_pkt_mj").mean() * 1e3
                        for n in Ns], marker=MARK[p], color=GREY[p],
                   lw=1.8 if p == "SUBLY" else 1.0)
        ax[2].plot(Ns, [col(g[(p, str(n))], "delay_mean_s").mean() for n in Ns],
                   marker=MARK[p], color=GREY[p],
                   lw=1.8 if p == "SUBLY" else 1.0)
    ax[0].set_ylabel("PDR (%)"); ax[0].set_ylim(0, 105)
    ax[0].axhline(95, ls="--", c="k", lw=0.7)
    ax[1].set_ylabel(r"Energy per packet ($\mu$J)"); ax[1].set_yscale("log")
    ax[2].set_ylabel("Mean delay (s)")
    for a, t in zip(ax, "(a) (b) (c)".split()):
        a.set_xlabel("Number of nodes $N$")
        a.set_title(t, loc="left", fontsize=8)
    fig.tight_layout()
    shared_legend(fig, ncol=7, y=-0.13)
    save(fig, "fig_scalability.pdf")


def fig_mobility():
    rows = load("mobility")
    g = group(rows, "protocol", "sweep_v")
    Vs = sorted({float(r["sweep_v"]) for r in rows})
    fig, ax = plt.subplots(1, 2, figsize=(W1, 2.15))
    for p in ORDER:
        k = [str(v) for v in Vs]
        ax[0].errorbar(Vs, [col(g[(p, s)], "pdr").mean() for s in k],
                       yerr=[ci95(col(g[(p, s)], "pdr")) for s in k],
                       marker=MARK[p], color=GREY[p], label=p, capsize=1.6,
                       lw=1.8 if p == "SUBLY" else 1.0)
        ax[1].plot(Vs, [col(g[(p, s)], "delay_mean_s").mean() for s in k],
                   marker=MARK[p], color=GREY[p],
                   lw=1.8 if p == "SUBLY" else 1.0)
    ax[0].set_ylabel("PDR (%)"); ax[0].set_ylim(30, 105)
    ax[1].set_ylabel("Mean delay (s)")
    for a, t in zip(ax, "(a) (b)".split()):
        a.set_xlabel(r"$v_{\max}$ (m/s)")
        a.set_xticks([0.0, 0.6, 1.2, 1.8, 2.4])
        a.set_title(t, loc="left", fontsize=8)
    fig.tight_layout()
    shared_legend(fig, ncol=3, y=-0.30)
    save(fig, "fig_mobility.pdf")


def fig_vsweep():
    rows = load("vsweep")
    g = group(rows, "sweep_V")
    Vs = sorted({float(r["sweep_V"]) for r in rows})
    d = [col(g[str(v)], "delay_mean_s").mean() for v in Vs]
    de = [ci95(col(g[str(v)], "delay_mean_s")) for v in Vs]
    e = [col(g[str(v)], "energy_per_pkt_mj").mean() * 1e3 for v in Vs]
    ee = [ci95(col(g[str(v)], "energy_per_pkt_mj") * 1e3) for v in Vs]
    fig, ax = plt.subplots(figsize=(W1, 2.1))
    ax.errorbar(Vs, d, yerr=de, marker="o", color="black", capsize=2,
                label=r"delay $\propto O(V)$")
    ax.set_xscale("log", base=2); ax.set_xlabel(r"Lyapunov weight $V$")
    ax.set_ylabel("Mean delay (s)")
    ax2 = ax.twinx()
    ax2.errorbar(Vs, e, yerr=ee, marker="s", color="0.5", ls="--", capsize=2,
                 label=r"energy $\propto O(1/V)$")
    ax2.set_ylabel(r"Energy per packet ($\mu$J)")
    ax2.grid(False); ax2.spines["right"].set_visible(True)
    h1, l1 = ax.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
    ax.legend(h1 + h2, l1 + l2, frameon=False, loc="upper left")
    save(fig, "fig_vsweep.pdf")


def fig_ablation():
    g = group(load("ablation"), "protocol")
    var = ["SUBLY", "SUBLY-noSub", "SUBLY-noLyap", "SUBLY-neither"]
    lab = ["full", r"$-$submod.", r"$-$Lyap.", r"$-$both"]
    fig, ax = plt.subplots(1, 2, figsize=(W1, 2.05))
    for a, (f, yl, sc) in zip(ax, [("pdr", "PDR (%)", 1.0),
                                   ("energy_per_pkt_mj", r"Energy/pkt ($\mu$J)", 1e3)]):
        m = [col(g[v], f).mean() * sc for v in var]
        er = [ci95(col(g[v], f) * sc) for v in var]
        a.bar(range(4), m, yerr=er, capsize=2, width=0.62,
              color=["black", "0.45", "0.65", "0.82"], edgecolor="black", lw=0.5)
        a.set_xticks(range(4)); a.set_xticklabels(lab, rotation=30, ha="right")
        a.set_ylabel(yl)
    for a, t in zip(ax, "(a) (b)".split()):
        a.set_title(t, loc="left", fontsize=8)
    fig.tight_layout()
    save(fig, "fig_ablation.pdf")


if __name__ == "__main__":
    fig_qos_energy(); fig_overhead_balance(); fig_lifetime()
    fig_scalability(); fig_mobility(); fig_vsweep(); fig_ablation()
