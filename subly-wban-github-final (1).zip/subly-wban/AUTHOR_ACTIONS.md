# Author actions

All previously open items have been applied. Two things remain, both noted below.

## Applied

| Item | Change | Evidence |
| --- | --- | --- |
| False ablation claim | "still ahead of every benchmark" -> "still ahead of every multi-hop benchmark" (`paper/main.tex`) | Seeds 0-9, same config: SUBLY-neither 97.08% PDR / 851 uJ; DTx 98.96% / 1488 uJ. The corrected form holds on both metrics against all five multi-hop benchmarks. |
| Scalability claim | "only scheme" -> "only multi-hop scheme", 4 sites | DTx minimum PDR across N=16-128 is 98.35%; next-best multi-hop is LEACH at 60.40%. |
| FND provenance | Time-to-first-node-death detached from the main-experiment list and attributed to the energy-constrained configuration (E0=0.12 J, 20 paired trials), 3 sites | `scripts/run_experiments.py` L32-37. The ratio does not hold in `main.csv`. |
| Ablation ratio | "roughly eightfold" -> "roughly ninefold" | Jain ratio 0.1227/0.01354 = 9.06; energy ratio 14.32%/1.49% = 9.60. |
| LND censoring | Disclosure added to the Table caption | `scripts/make_tables.py` L149-150 right-censors at the 600 s horizon. SUBLY 18/20, DTx 19/20, QQAR 20/20 reached the event. |
| Related-work duplication | LEACH, IM-SIMPLE and EHCRP paragraphs merged; every proposition preserved, restatements removed. Template sentences reduced 7 -> 4. | Remaining four state propositions distinct from their preceding sentence. |
| EHCRP code docstring | Now states the published cost (energy, hops, congestion, SNR, bandwidth) and the deviation | MDPI abstract, Sensors 20(21):6267. |
| Editorial annotations | 148 lines removed from the manuscript source | Archived outside the repository. |
| Citations | mgwoql2022 (vol. 210), simple2013 (pp. 221-226, DOI), ehcrp2020 (20(21):6267), mattempt2013 ("Fareed") verified against publisher records | ScienceDirect, IEEE Xplore, DBLP, MDPI, PMC, ACM DL. |
| Packaging | README, LICENSE, .gitignore added; repository restructured; figure PDFs made byte-deterministic | `pip install .` verified in a clean venv. |

## Remaining

**1. LICENSE copyright holder.** `LICENSE` contains the MIT text declared in
`pyproject.toml`, but the copyright line reads `<COPYRIGHT HOLDER>`. The
manuscript is anonymised, so the name could not be filled in without inventing
it. Replace before publishing.

**2. Parameter tuning (disclosed limitation, not a defect).** The SUBLY
parameters were fixed on seeds {1, 2, 3}, which overlap the evaluation range
0-29. The repository contains no tuning script, so this could not be repaired
reproducibly; no data was altered and no tuning history was synthesised. The
manuscript discloses it at L1074 and in the limitations section, and makes no
claim of holdout tuning or independent validation. Repairing it would require
writing and running a real tuning procedure.

## Not done, deliberately

- Dijkstra (named, uncited) and the potential-based loop-freedom construction
  (asserted, uncited) have no citation added. Both are standard; no reference
  was inserted from memory.
- The LEACH "factor of 8" energy figure remains unverified; the manuscript keeps
  it qualitative, so no citation risk remains.
- No commit history, timestamps, drafts, citations or experimental records were
  fabricated. No AI-detection was performed and no authorship judgment was made.
